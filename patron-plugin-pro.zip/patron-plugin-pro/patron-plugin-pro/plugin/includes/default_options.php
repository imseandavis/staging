<?php


$this->opt = array_replace_recursive(

	$this->opt,

	array(
	
			'template'=> 'default',
			'patreon_client_id'=> '',
			'patreon_client_secret'=> '',
			'patreon_creator_access_token'=> '',
			'patreon_creator_refresh_token'=> '',
			'setup_done'=> false,
			'license'=> '',
			'content_locking'=> array(
			
				'custom_button'=> '',
				'custom_excerpt_button'=> '',
				'custom_excerpt_listing_button'=> '',
				'custom_button_width'=> '200',
				'custom_excerpt_button_width'=> '200',
				'custom_excerpt_listing_button_width'=> '100',
				'patron_only_heading_font_size'=> '125',
				'patron_only_excerpt_heading_font_size'=> '110',
				'patron_only_excerpt_listing_heading_font_size'=> '75',
				'custom_patron_only_heading'=> '',
				'custom_patron_only_excerpt_heading'=> '',
				'custom_patron_only_excerpt_listing_heading'=> '',
				'patron_only_heading_bold'=> 'yes',
				'patron_only_excerpt_heading_bold'=> 'yes',
				'patron_only_excerpt_listing_heading_bold'=> 'yes',
				'custom_button_margin'=> '15px',
				'custom_excerpt_button_margin'=> '15px',
				'custom_excerpt_listing_button_margin'=> '5px',
				'patron_only_excerpt_padding'=> '10px',
				'patron_only_excerpt_listing_padding'=> '5px',
				'patron_only_content_padding'=> '0px',
				'only_ppp_banners'=> 'yes',
				'custom_button_new_window'=> 'no',
				'custom_excerpt_button_new_window'=> 'yes',
				'custom_excerpt_listing_button_new_window'=> 'yes',
				'custom_excerpt_listing_banner_wrapper_horizontal_alignment'=> 'left',
				'custom_excerpt_listing_button_show'=> 'no',
				'show_excerpts_for_locked_post'=> 'no',
				'put_users_to_pipeline'=> 'yes',
				'entire_site_patron_only'=> 'no',
				'gate_excerpts_in_listings'=> 'yes',
				'post_locking_value'=> '0',
				'only_patrons_with_amount'=> '0',
				'lock_last_x_posts'=> '0',
				'lock_after_x_days'=> '0',
				'only_patrons_login_message_1'=> '',
				'patron_only_excerpt_background_color'=> '#f4f4f4',
				'only_patrons_login_message_2'=> '',
				'excerpt_before_locked_post_format_length'=> 35,
				'always_login_allowed_roles'=> array(
					'administrator' => 'Administrator',
					'editor' => 'Editor',
				),
				'excerpt_before_locked_post_format'=> '<h3>Below is a sneak peek of this content!</h3>
{%%show_excerpt_here%%}<p></p>',
			
			
			),
			'sidebar_widgets' => array(
			
			),
			
		)
		
		

);


?>