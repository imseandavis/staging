<?php


$notice = '<img src="'.$this->internal['plugin_url'].'images/New-Feature-Notice.png" style="float:left;margin-right: 10px; margin-bottom: 10px;" /><h3>Patron Plugin Pro: Reconnection Feature Improvement</h3><b>
Now the reconnection feature at WP admin -> Patreon Settings -> "(re)Connect Site" can be used to fix the connection of your site to Patreon even if the connection was totally broken. Whenever you think that your site\'s connection to Patreon may be broken, use the reconnect feature.</b><br><br>In <a href="https://codebard.com/patron-pro-feature-highlights-from-updates" target="_blank">this page</a>, you can find the summary for new features and changes for all recent Patron Pro versions.';

/*

$notice = '<img src="'.$this->internal['plugin_url'].'images/New-Feature-Notice.png" style="float:left;margin-right: 10px; margin-bottom: 10px;" /><h3>Patron Pro Shortcode Locking Bug Fixed</h3><b>
A bug that prevented ppp_patron_only and ppp_non_patron_only shortcodes from working was fixed. Now you can use ppp_patron_only shortcode to lock parts of your post or page content to make it for patrons-only as before. Similarly, ppp_non_patron_only shortcode can be used to show content only to non-patrons (ads etc)<br><br><a href="https://codebard.com/codebard-news-updates/patron-pro-1-5-1-is-out-with-improved-pledge-handling-and-included-plugin-updates" target="_blank">Read details here!</a></b><br><br>In <a href="https://codebard.com/patron-pro-feature-highlights-from-updates" target="_blank">this page</a>, you can find the summary for new features and changes for all recent Patron Pro versions.';


*/


?>