( function() {
    tinymce.PluginManager.add( 'tinymce_patron_only_button_plugin', function( editor, url ) {

        // Add a button that opens a window
        editor.addButton( 'tinymce_patron_only_button', {

            text: 'Patron Only',
            icon: false,
            onclick: function() {
             
				selected_text = tinyMCE.activeEditor.selection.getContent();

				jQuery('#ppp_patron_only_dialog' ).css('opacity', 1.0);
				
				if ( selected_text == '' ) {
					jQuery('#ppp_patron_only_dialog' ).html('Please select some content to make patron only. You can do this by selecting part of your content and then clicking Patron only button');
					jQuery('#ppp_patron_only_dialog' ).dialog({autoResize:true});
					return;
				}			
		
				jQuery('#ppp_patron_only_dialog').html('');
				//const regex = /(\[ppp_patron_only(.*?)\])/gm;
				
				//var regex = new RegExp("[ppp_patron_only" + testVar + "]");

		
				// var patreon_level = selected_text.match(regex).pop();
				var shortcode = /(\[ppp_patron_only(.*?)\])/.exec(selected_text);

				// The match for args should be in 3rd index
				
				var patreon_level = "1";
				var level = null;
				var silent_fetch = null;
				var silent = 'no';
				
				if ( shortcode != null ) {
						
					var args = shortcode[2].trim();
					
					if( args != null ) {
						
						// var patreon_level = selected_text.match(regex).pop();
						var level_fetch = /(\level="(.*?)\")/.exec(args);

						// The match for args should be in 3rd index

						if ( level_fetch !== null ) {
							var level = level_fetch[2].trim();
						}
						
						// var patreon_level = selected_text.match(regex).pop();
						var silent_fetch = /(silent="(.*?)\")/.exec(args);

						// The match for args should be in 3rd index
						if ( silent_fetch !== null ) {
							var silent = silent_fetch[2].trim();
						}
						
					}
					
				}

				var silent_checked = '';
				if ( silent == 'yes' ) {
					silent_checked = ' checked="checked"';
				}
				
				// Update Patreon level with acquired level
				if ( level != null) {
					patreon_level = level;
				}
				
				if( shortcode != null ) {
					// Remove all instances of shorcode
					
					selected_text = selected_text.replace(/(\[ppp_patron_only(.*?)\])/gi,'');
					selected_text = selected_text.replace(/(\[\/ppp_patron_only])/gi,'');
					
				}

				// QTags.insertContent('[ppp_patron_only level="5"]' +  selected_text + "[/ppp_patron_only]");
				
				jQuery('#ppp_patron_only_dialog' ).prepend('Set the level for this excerpt<div id="ppp_patron_only_excerpt_level_input">$<input size="2" id="ppp_patron_only_excerpt_level_value" type="text" value="'+patreon_level+'" /></div>Silent - don\'t show unlock button<div id="ppp_patron_only_excerpt_silent"><input type="checkbox" id="ppp_patron_only_excerpt_silent_checkbox" type="text" value="yes" '+silent_checked+' /></div><input type="submit" name="ppp_level_submit" id="ppp_patron_only_excerpt_level_submit" class="button button-primary" value="Save"><div id="ppp_patron_only_excerpt_to_be">'+selected_text+'</div><div id="ppp_patron_only_excerpt_level_input_source" source="visual" style="display:none;"></div><br /><br />');
				
				
				jQuery('#ppp_patron_only_dialog' ).dialog({autoResize:true});				  
							
			   // content =  '[ppp_patron_only]'+selected+'[/ppp_patron_only]';
				
			
			// tinymce.execCommand('mceInsertContent', false, content);
            }

        } );

    } );

} )();