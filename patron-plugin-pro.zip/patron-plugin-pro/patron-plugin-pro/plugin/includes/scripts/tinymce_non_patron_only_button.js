( function() {
    tinymce.PluginManager.add( 'tinymce_non_patron_only_button_plugin', function( editor, url ) {

        // Add a button that opens a window
        editor.addButton( 'tinymce_non_patron_only_button', {

            text: 'Non-Patrons Only',
            icon: false,
            onclick: function() {

				selected_text = tinyMCE.activeEditor.selection.getContent();
				content =  '[ppp_non_patron_only]'+selected_text+'[/ppp_non_patron_only]';
				tinymce.execCommand('mceInsertContent', false, content);
            }

        } );

    } );

} )();