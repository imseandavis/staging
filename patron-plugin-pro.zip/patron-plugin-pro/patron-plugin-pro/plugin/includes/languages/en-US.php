<?php


$lang = array(
	'lang' => 'en-US',
	'current_lang_label' => 'English (US)',
	'admin_tab_patreon_api' => 'Patreon API',
	'admin_tab_content_locking' => 'Content Locking',
	'admin_tab_customize_interface' => 'Customize Interface',
	'labelcontinue' => 'Continue',
	'custom_banner_label' => 'Sneak Peek',
	'plugin_name' => 'Patron Plugin Pro',
	'success_language_operation_successful' => 'Language operation was successful',
	'patreon_creator_id' => 'Your Patreon Creator ID',
	'option_info_patreon_creator_id' => 'This is your Patreon Creator ID. We need it to be able to put your Users directly into Patron pipeline.',
	'custom_patron_only_excerpt_listing_heading' => 'For Patrons only. Please become a patron',
	'admin_menu_label' => 'Patron Plugin Pro',
	'this_content_is_patron_only' => '',
	'this_content_is_patron_only_excerpt' => '',
	'this_content_is_patron_only_no_level' => '',
	'this_content_is_patron_only_excerpt_level' => 'Sorry! This part of content is hidden behind this box because it requires a higher contribution level ($***patreonlevelrequirement***) at Patreon. Why not take this chance to increase your contribution?',
	'error_auto_parsing_credentials_failed' => 'Sorry! Automatic input of credentials failed. Please make sure to copy/paste exact text as specified, or copy and paste relevant fields to relevant input boxes one by one',
	'error_auto_parsing_login_failed' => 'Sorry! Automatic input of login failed. Please make sure to copy/paste exact text as specified.',
	'learn_how_to_get_credentials' => 'Click here to learn how to get below info',
	'learn_how_to_get_login' => 'Click here to learn how to get your Login ID',
	'update_available' => 'A new version of Patron Plugin Pro is available! Please update your plugin to benefit from security fixes, bug fixes and new features. To update your plugin, <a href="{***plugin_update_url***}" target="_self">click here</a>',
	'please_enter_your_license_key' => 'Please enter your license key',
	'save_license' => 'Save License',
	'save' => 'Save',
	'change_license' => 'Update',
	'license_successfully_saved' => 'License saved successfully!',
	'license_invalid' => 'License not valid. Please correct and try again.',
	'site_inactive' => 'This site is not active for this license',
	'license_check_connect_failed' => 'Could not verify license with remote server',
	'license_active' => 'License active',
	'license_inactive' => 'License inctive',
	'patron_plugin_pro_label' => 'Patron Plugin Pro',
	'plugin_is_almost_ready' => 'is almost ready!',
	'plugin_is_ready' => 'is now ready!',
	'setup_wizard_keep_in_touch' => 'Keep in touch with us below for info on new features, updates, security and bugfixes',
	'setup_wizard_follow_us_on_twitter' => 'Follow us on Twitter',
	'setup_wizard_twitter_follow_label_prefix' => 'Follow',
	'setup_wizard_join_list' => 'Join our Newsletter',
	'setup_wizard_join_mailing_list_link_label' => 'Subscribe',
	'setup_read_quickstart_guide' => 'Read Quickstart Guide',
	'setup_assign_products_and_orders_to_departments' => 'Assign Products or Orders to Departments',
	'fine_tune_woocommerce_settings' => 'Turn on Product, Order selection and requirements for ticket opening',
	'setup_now_you_can' => 'Now if you want, you can...',
	'setup_wizard_done' => 'Done! That\'s it! Now you can enjoy full features of Patreon!',
	'setup_wizard_if_you_have_questions' => 'If you have questions, you can visit <a href="https://codebard.com/support" target="_blank">here</a> to get support!',
	'patreon_client_id' => 'Patreon Client ID',
	'option_info_patreon_client_id' => 'This is the Client ID that is found in <a href="https://www.patreon.com/platform/documentation/clients" target="_blank">your Patreon application page at Patreon</a>.',
	
	'patreon_client_secret' => 'Patreon Client Secret',
	'option_info_patreon_client_secret' => 'This is the Client Secret that is found in <a href="https://www.patreon.com/platform/documentation/clients" target="_blank">your Patreon application page at Patreon</a>.',
	
	'patreon_creator_access_token' => 'Patreon Creator Access Token',
	'option_info_creator_access_token' => 'This is the Creator Access Token that is found in <a href="https://www.patreon.com/platform/documentation/clients" target="_blank">your Patreon application page at Patreon</a>.',
	
	'patreon_creator_refresh_token' => 'Patreon Creator Refresh Token',
	'title_mark_patron_only_metabox' => 'Mark entire post Patron only',
	
	
	'option_info_creator_refresh_token' => 'This is the Creator Refresh Token that is found in <a href="https://www.patreon.com/platform/documentation/clients" target="_blank">your Patreon application page at Patreon</a>.',
	'patron_only_label' => 'Patron Only',
	 
	'gotta_get_the_api_credentials' => 'We have to link your site with Patreon to make use of advanced functions.<br><br>Don\'t worry - it\'s easy - just follow the exact steps below:' ,

	'api_credentials_failed_during_setup' => 'Oops! Sorry - couldn\'t parse credentials. We must get the credentials for advanced functionality to work. You can retry by clicking "Click here to learn how to get below info" at <a href="'.admin_url().'admin.php?page=settings_cb_p6&cb_p6_tab=patreon_api">this page</a> or manually copy paste each credential at that same page.' ,
	'api_credentials_failed_during_setup_support' => 'If this problem persists, or you are not sure how to do that, please contact support <a href="https://codebard.com/support">here</a>' ,
	
	
	'cb_p6_required' => 'Patron Plugin Pro requires Patreon Button, Widgets and Plugin by CodeBard to function. Please install the plugin <a href="{***PLUGINLINK***}">by clicking here</a>.',
	
	
	'adjust_content_locking' => 'Adjust your Patron-only Content settings' ,
	'manual_link_label' => 'Read the Manual' ,


	'month_01' => 'January' ,
	'month_02' => 'February' ,
	'month_03' => 'March' ,
	'month_04' => 'April' ,
	'month_05' => 'May' ,
	'month_06' => 'June' ,
	'month_07' => 'July' ,
	'month_08' => 'August' ,
	'month_09' => 'September' ,
	'month_10' => 'October' ,
	'month_11' => 'November' ,
	'month_12' => 'December' ,
	
	'label_start_date_month' => 'Start Month' ,
	'label_end_date_month' => 'End Month' ,
	'day' => 'Day' ,
	'month' => 'Month' ,
	'year' => 'Year' ,
	'date' => 'Date' ,
	'start_date' => 'Starting From' ,
	'end_date' => 'Until' ,
	
	
	'pat_wordpress_missing' => 'Patreon WordPress plugin is required for Patron Pro to work! Currently its not installed or activated! To find out how to install it, please refer to the <a href="https://codebard.com/installing-patron-plugin-pro" target="_blank">installation manual here</a>.',
	
	'cb_p6_missing' => '<h2>Patron Pro configuration needs update!</h2>At least one plugin in Patron Pro package is not installed, inactive or must be updated. This may prevent Patron Pro from working. Please use setup wizard to get more information and auto-fix:<br>
	<button class="admin-button">Go to the Wizard</button>',
	
	'required_plugins_missing' => '<h2>Patron Pro configuration needs update!</h2>At least one plugin in Patron Pro package is not installed, inactive or must be updated. This may prevent Patron Pro from working. Please use setup wizard to get more information and auto-fix:<br>
	<form method="post" action="'.$this->internal['admin_url'].'admin.php?page=setup_wizard_'.$this->internal['id'].'">
	<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Go to the Wizard"></p></form>',
	
	'setup_not_complete' => '<h2>Patron Pro setup incomplete!</h2>We must finish setup and connect your site to Patreon in order for you to enjoy Patreon features at your site. Please resume the setup wizard to complete configuration of the plugin:
	<form method="post" action="'.$this->internal['admin_url'].'admin.php?page=setup_wizard_'.$this->internal['id'].'">
	<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Go to the Wizard"></p>
	</form>',
	
	'mark_metabox_info' => 'This option sets the post level to $1 and makes it patron only. If you set a gate level at the "Patreon Level" box, or used Advanced Locking Options, checking this box is not necessary.',
	
	'patron_only_advanced_label' => 'Advanced Locking',
	'mark_metabox_advanced_info' => 'This advanced locking option overrides all others',
	'advanced_start_date' => 'Lock starting from',
	'advanced_end_date' => 'Show starting from',
	'only_patrons_login_message_1' => 'Sorry, only patrons with $',
	'only_patrons_login_message_2' => ' pledge or over can login and use our site features. Why not take this chance to become our patron or update your pledge?',
	'vip_user_label' => 'VIP',
	'vip_user_description' => 'If marked VIP, this user will be able to access all Patreon locked content',
	'patreon_user_level_label' => 'Custom Patreon level',
	'patreon_user_level_description' => 'If you enter a $ value here, this user will be treated as a Patreon subscriber from that level, even if s/he isn\'t. <br /> This allows the user to access content that is marked at or lower than this $ level. <br /> Not necessary for users marked as VIP',
	'content_will_be_public_1' => 'This content will be free for everyone in ',
	'content_will_be_public_2' => ' day(s)',
	'patron_greeting_widget_name' => 'Patreon Custom Patron Greeting',
	'patron_greeting_tier_title_non_patron' => 'Hey!',
	'patron_greeting_tier_title_default' => 'Hey {patronname}!',
	'patron_greeting_widget_desc' => 'Show customized greetings to your patrons based on tiers',
	'customize_patron_greeting_info_in_widget' => 'The above are uneditable examples - just customize the greeting title and message for every tier <a href="'. admin_url( 'admin.php?page=settings_cb_p6&cb_p6_tab=sidebar_widgets#patron_greeting_section' ) .'">here</a>',
	'patron_greeting_tier_message_non_patron' => 'Hey there! Welcome to '.get_bloginfo(),
	'patron_greeting_tier_message_default' => 'Hey {patronname}! Thanks for supporting us!',
	'label_over_universal_button_lifetime_locking' => 'This content is available exclusively to members of <a href="%%creator_link%%" target="_blank">%%creator%% Patreon</a> who have at least $%%total_pledge%% lifetime pledge in total. You have %%user_lifetime_pledge%% and',
	'label_over_universal_button_lifetime_locking_qualify_months' => 'you will qualify for access in %%remaining_months%% months. Upgrade to a higher tier to qualify faster!',
	'valid_patron_label_lifetime_locking' => 'This content is available exclusively to members of <a href="%%creator_link%%" target="_blank">%%creator_page_name%% Patreon</a> who have at least $%%total_pledge%% lifetime pledge in total. You have $%%user_lifetime_pledge%% and you qualify for this content.',
	'label_over_universal_button_lifetime_locking_non_patron' => 'This content is available exclusively to members of <a href="%%creator_link%%" target="_blank">%%creator%% Patreon</a> who have at least $%%total_pledge%% lifetime pledge in total.',
	

);


?>