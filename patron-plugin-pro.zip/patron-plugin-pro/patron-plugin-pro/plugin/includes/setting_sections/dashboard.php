<?php


$old_error_reporting = error_reporting(0);


if(!isset( $_REQUEST['license'] ) OR $_REQUEST['license']=='')
{
	
	$_REQUEST['license']=$this->opt['license'];

}


echo '<form action="admin.php?page=settings_'.$this->internal['id'].'&'.$this->internal['prefix'].'tab=dashboard" id="department_form" name="" method="post"  enctype="multipart/form-data">';


echo '<span class="'.$this->internal['prefix'].'h3">'.$this->lang['title_your_license_explanation'].'</span>';


echo '<br>';
echo '<input type="text" id="'.$this->internal['prefix'].'license" name="license" value="'.$_REQUEST['license'].'">';


echo '<button type="submit" class="'.$this->internal['prefix'].'admin_button"  aria-label="Save">'.$this->lang['save'].'</button>';
echo '<input type="hidden" name="'.$this->internal['prefix'].'action" value="save_license">';
echo '<input type="hidden" name="cb_plugin" value="'.$this->internal['id'].'">';

echo '</form>';


error_reporting($old_error_reporting);

?>