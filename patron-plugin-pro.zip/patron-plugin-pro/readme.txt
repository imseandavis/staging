===  Patron Plugin Pro ===
Author URI: https://codebard.com
Plugin URI: https://codebard.com/patron-button-pro/
Contributors: CodeBard
Donate link: https://codebard.com/donate
Tags: plugins, patreon, widgets, crowdfunding, crowdfund, crowd fund, crowd funding, sponsor, donate, donations, donation, charity, fundraising, charities, sponsorship, sponsorships, campaign, campaigns, giving, peer to peer, peer to peer fundraising, fundraiser, peer to peer fundraiser, non profit, non profits, income, money, subscription, social, rewards, kickstart
License: GPL
Requires at least: 4.0
Tested up to: 6.5.2
Stable Tag: 1.6.2

Patron Plugin Pro for Patreon

== Description ==

Patron Plugin Pro for Patreon

== Installation ==

1. Activate the plugin
2. Patron Plugin Pro will become active
3. Follow the install wizard

== Upgrade Notice ==

= 1.6.2 =

* Now the reconnection feature at WP admin -> Patreon Settings -> (re)Connect can be used to fix the site's connection to Patreon even if the connection was broken
* Updated libraries
* Gaussian blur filter added

= 1.6.1 =

* Fixed the issue with Import next batch button not working immedieatly after starting a manual post import
* Added two new cases for error messages for needing admin privileges to start manual post sync and for the case of expired nonce
* Added a Cancel button to the manual post import interface.

= 1.6.0 =

* Fixed a PHP warning that could appear during setup
* Patched minor CSRF vulnerability

= 1.5.9 =

* Patched minor CSRF vulnerability

= 1.5.8 =

* The missing 'Already a member? Refresh ..." text label under the locked post interfaces was fixed - now it appears properly
* A PHP warning about Patreon_Wordpress not being available was fixed
* Settings tab resetting & going to dashboard when saving a setting was fixed
* An issue with settings tabs not working correctly was fixed
* An issue with cross site scripting vulnerability was fixed
* Various forms and actions had security nonces added
* Issue with not being able to save some options in the options page was fixed. (Post sync options etc)
* Fixed a potential warning in the locked post interface

= 1.5.7 =

* Fixed an issue with day count showing 0 or negative amount of days when locking post types/categories/taxonomies with 'Show after X days'
* Updated core function to avoid requiring admin privileges breaking wp cli or frontend pages
* Fixed a potential PHP warning about tier title
* Fixed a potential PHP warning when upgrading
* Improved license checking
* Updated button and widgets plugin

= 1.5.6 =

* Added extra sanitization against cross-site script attacks

= 1.5.5 =

* Fixed a bug that could prevent WP cli used in managed hosting services from failing in certain tasks
* Addressed a PHP warning
* Addressed a minor security issue
* Renamed "Custom patron only banner" label in post editor to "Sneak Peek" for more clarity.

= 1.5.4 =

* Fixed an issue with final screen of the setup wizard not displaying properly
* Fixed documentation and quickstart links not working in final setup wizard screen
* Added aria labels for screenreaders for accessibility
* Fixed an issue in which the app icon was not displaying in Patreon login/pledge confirmation screen. Now it should work after reconnecting the site to Patreon.
* Added link to Codebard Patreon campaign
* Removed now unneeded api tab in settings
* Fixed various PHP warnings
* Better handling of current user's pledge

= 1.5.3 =

* Fixed an issue that prevented patron only content shortcode from working. Using partial post locking with ppp_patron_only now should work without creating any error.
* Fixed an issue that prevented non-patron only content shortcode from working. Showing content to non-patrons with ppp_non_patron_only now should work without creating any error.
* Code that generated PHP warnings was fixed.

= 1.5.2 =

* Added new filter vars for enabling upcoming unlock action logging feature
* From PW: Modified lock or not filter to feed more variables to functions.
* From PW: Added and calculated relevant variables during unlock process
* From PW: Added a check for the timestamp of saved patron info
* From PW: Now uses the saved patron info if the timestamp is within 2 seconds of current Unix time and does not call the API
* From PW: Now saves the timestamp of the time when a user has returned from any Patreon flow
* From PW: getPatreonUser now checks for that timestamp in order to decide whether to call the api or not

= 1.5.1 =

* Improved handling of pledge checking - now declined patrons should have the grace period that is applied at patreon.com. This will improve content unlocking and reduce the number of patrons not being able to access content that they qualify for
* Locked content interface text updated to accommodate all currencies
* Included from PW: Made currency sign selection a text input instead of select
* Included from PW: Modified the currency sign option to be currency sign at the front of the amount
* Included from PW: Added a currency sign option to be used at the end of the amount
* Included from PW: All text updated to use the currency sign that is saved in options. $ if default.
* Included from PW: Added call throttling to api calls to avoid spamming of the api by zombie or faulty sites
* Included from PW: Added throttled-return handling to relevant functions
* Included from PW: Added callouts for easy access to plugin upgrade

= 1.5.0 =

* Included all required plugins inside the plugin itself. This will make it easier to install and update the plugin. Recommended.
* Now it needs one less step to complete the setup
* Made compatible with the required plugins if the required plugins are installed separately. The plugin will work in either case and fall back to the included versions if those other plugins are not present. This will prevent functionality and Patreon features from being broken in the case of missing plugins.
* Updated the priority of the Advanced Locking metabox. This will make it easier to find and use.
* Update in included library: An issue with image locking that affected thumbnail size images fixed
* Update in included libraries: Patron Content Manager addon notice hidden if Patron Plugin Pro is active - Patron Plugin Pro handles the PCM notice now

= 1.4.9 =

* Content drip locking added. Now content can be locked for lifetime pledge to allow content drip.
* Added locked post banner text to be shown to non patrons when post is locked with content drip
* Added locked post banner text to be shown to non-qualifying patrons when post is locked with content drip
* Added post footer text to be shown to qualifying patrons when post is locked with content drip
* Now overrides the tier title with $ amount if there are no tiers. This will address various PHP Warnings/Notices that were appearing on dev sites or error logs.
* Address a PHP notice/warning while filtering flow link.
* Removed now unused patreon_nonce var. This should address various login problems.
* Fixed a potential issue with 'Support at Patreon' post button from Buttons plugin being shown to qualifying patrons in unlocked posts.
* Added knowledgebase links to advanced locking methods.

= 1.4.8 =

* Added compatibility with PW's new post sync wizard screens
* Fixed a minor issue with a PHP warning about wp_version

= 1.4.7 =

* Added compatibility with Paid Memberships Pro to allow unlocking PMP gated content via Patreon
* Added compatibility with Paid Memberships Pro to allow unlocking Patreon gated content via PMP
* Made 'Become a Patron' button at the end of posts to be hidden when a post is gated with PMP
* Fixed issue with slashes being added to summaries added in "Patron-only Post Summary in Post Listing Heading" option in Content Locking section
* Modified JavaScript code to reduce chances of interfering with any other plugin's JS code.
* Modified JavaScript code to reduce chances of interfering with any other plugin's JS code.

= 1.4.6 =

* Date based locking or date based showing now allows gating for dates up to 5 years in the future

= 1.4.5 =

* Worked around  WP 5.3 bug that causes a PHP notice that stems from an issue in WP itself.

= 1.4.4 =

* Addressed PHP submenu notice error in WP 5.3
* Updated widget and post button link construction logic
* Better decision on which link to use.
* Made Author widget to go to author's profile if exists

= 1.4.3 =

* Multi line custom patrong greetings now work.

= 1.4.2 =

* Saved greeting for non patrons is loaded properly after switching back and forth in between different tier greetings. Before it loaded default greeting as opposed to saved one.

= 1.4.1 =

* Tier dropdown for Custom Patron Greeting widget made to work with text mode in tier message editor
* Now downloads and installs Patreon WordPress from WP repo

= 1.4.0 =

* An advanced widget, Custom Patron Greeting widget that allows site owners to show customized greetings/messages to their patrons based on their tier was added

= 1.3.9 =

* An issue causing errors and redirections during setup wizard's Patreon connection phase was fixed

= 1.3.8 =

* Content locking options updated to become intuitive and provide easy way to save the selected locking option
* Your creator profile url and page name are now synchronized with Patreon WordPress settings
* Patron Pro will now avoid gating content if you have not connected your site to Patreon
* utm parameters are added to creator profile links

= 1.3.7 =

* Now automatically sets your Patreon profile url for button and widgets

= 1.3.6 =

* Made compatible with PW's new easy setup wizard
* Setup wizard screens modified to accommodate new setup flow

= 1.3.5 =

* An issue which caused misidentification of VIP users, leading them to see higher tiers content was fixed

= 1.3.4 =

* A major bug causing login lock to not work for normal user/pass logins for users who registered via Patreon before, was fixed.
* Login lock now places users on pledge flow so that they can pledge and auto login easily.
* Creator profile url was appearing as %%creator_url%% in locked post interface. This was fixed.
* Patron Pro now auto-fills your profile url if you have not entered your profile url in Quickstart settings, this fixes 404 problems with 'Become a Patron' button.
* If you turned 'Put users directly to Patron Pipeline when they click a "be our patron" button' setting on, now it uses a $1 pledge amount to make them patrons.
* A bug was causing issues with admin-side notices from the plugin. This was fixed.

= 1.3.3 =

* A minor setup bug which caused error message when installing the plugin in PHP 7.1 and 7.2 sites was fixed.
* An issue which caused after update notices not to be dismissible in some installations was fixed.

= 1.3.2 =

* Notable bug which caused lifetime pledge of patrons to not get recognized during post lock/show decisions was fixed. Now if a patron which satisfies the lifetime pledge requirement you set for a post views the post, s/he will get access to it.
* Empty space was generated by custom banner code even in cases there was no custom banner. Now the code for custom banner will appear only when there is any custom banner of any sort.
* Display logic for custom locked post banners improved. Now if its set, it shows Custom sitewide PW banner first, then overrides it with Patron Pro banner if its set, and then overwrites it with custom banner set in the post editor for that post if it is set. No banner is shown if none of these are present.
* Custom Patreon banner for the post metabox was moved to side in order to have it display in Gutenberg editor and classic editor at the same time.
* Now tier name required to view the post is shown instead of the $ level in the interface on locked posts.

= 1.3.1 =

* Manual excerpt capability for sneak peek feature added
* Nested shortcodes should now work

= 1.3.0 =

* Category, tag, custom taxonomy locking feature added
* Background color selection added for locked post excerpts
* Content locking section revamped
* Age countdown fixed for age locked posts
* Login lock feature now recognizes VIP and custom level users
* ***patreonlevelrequirement*** variable made work with custom text for locked post excerpts

= 1.2.7 =

* Locked excerpts can now be locked for $ level
* jQuery modal interface added to allow easy entry of $ level when locking excerpts
* Non-patrons only shortcode added. Allows showing parts of posts to non-patrons only (ads etc)
* Buttons for non-patron only shortcode added to visual and text editor (classic)
* Major bug that prevented login lock feature from working was fixed

= 1.2.6 =

* Now provides VIP user and custom $ level user features
* VIP and Custom $ level users now have specific valid patron footers that tell them they access the content because they are special
* Priority of Patron Pro meta boxes in post editor set to default so they wont get ahead of normal WP post editor boxes
* Patron Widgets Plugin's post button now made to be hidden if the user is a valid patron viewing a locked content since there is no point to show already paying patrons a call to action for patronage

= 1.2.5 =

* Plugin installer wizard now reports errors if plugin processes failed due to server/site configuration
* A bug which caused site-wide custom banner and post-specific custom banner to not appear was fixed
* Added option that allows controlling alignment of banners in post listings
* Defaulted horizontal alignment of banners in post listings to left instead of earlier center - to be compatible with majority of themes
* Added an option to show/hide buttons in banners in post listings
* Defaulted the buttons in banners in post listings to be hidden

= 1.2.4 =

* Implemented a plugin installer/updater/configurator
* Plugin will check if any needed plugins in the bundle are not installed, missing or wrong version, and disable itself and warn the site owner
* Setup wizard now will auto-install/update/configure needed plugins

= 1.2.3 =

* Fixed an issue where plugin was changing excerpt lengths

= 1.2.2 =

* Now checks for presence of required plugins, and warns the site owner and disables itself to prevent site errors

= 1.2.1 =

* Fixed harmless but annoying meta-printing debug code bug that caused post meta to be listed in post editor

= 1.2.0 =

* Now compatible with new API v2 features
* A bug preventing advanced post locking options from being removed from post was fixed 
* Now uses and modifies new API v2 related text for patron status
* Post metabox priority made default to prevent it from appearing over WP post editor post metabox
* Numerous small fixes

= 1.1.3 =

* An option to control sneak peek length added for locked posts. 
* Excerpts before locked posts option renamed to Sneak Peek.

= 1.1.2 =

* Login locking feature that allows you to lock logins to only patrons
* Add/remove user role exemptions to login lock feature
* Patron-only Content Notification Heading for Entire Post no longer adds slashes to the content

= 1.1.1 =

* Important issue that prevented saving language customizations and using them was fixed

= 1.1.0 =

* Compatible with Patreon's upcoming API v2
* Bug with advanced post locking options being deleted when post is saved without any change fixed

= 1.0.9 =

* New feature that shows post excerpts before locked posts - formattable

= 1.0.8 =

* Now shortcodes are applied inside Patron only snippet shortcode
* Now there is only a single login with Patreon button in login forms
* Tested to work with new Image locking functionality

= 1.0.7 =

* Advanced Locking options now available for Single Posts/Pages (including custom)
* "This content is for Patrons pledging " notice now removed from non-locked content

= 1.0.6 =

* Locking last (x) post types feature with pledge level
* Showing last (x) post types feature with pledge level
* Locking post types by post age feature with pledge level
* Locking post types by post date feature with pledge level
* Showing post types by post age feature with pledge level
* Plugin now enables locking of Pages
* New valid patron footer says how many days until post is locked if lock posts by age is set for the post type

= 1.0.5 =

* Users must update Patreon WordPress plugin manually before updating to this version
* Implemented new Patreon interface
* Plugin now automatically puts users into patron pipeline, makes them patron, and brings them back to content to be viewed
* Now Patreon Core, Patreon Core Custom, Patron Plugin Pro Custom and Custom Post Banners are all usable
* New post locking logic
* Fixed interface bugs
* Fixed locking bugs
* Fixed login bugs

= 1.0.4 =

* Major bugfix non-English (en-US) language sites and Out of Memory errors

= 1.0.3 =

* Major bugfix with utm_source parameter not being accepted by Patreon - a must update or URLS wont work!

= 1.0.3 =

* Major bugfix with utm_source parameter not being accepted by Patreon - a must update or URLS wont work!

= 1.0.2 =

* Minor bugfixes

= 1.0.1 =

* Minor bugfixes

= 1.0.0 =

* Initial release!

== Frequently Asked Questions ==

To be updated

== Screenshots ==

1. Screenshots to come

== Changelog ==

= 1.6.2 =

* Updated libraries
* Now the reconnection feature can be used to fix the site's connection to Patreon even if the connection was broken
* Gaussian blur filter added

= 1.6.1 =

* Fixed the issue with Import next batch button not working immedieatly after starting a manual post import
* Added two new cases for error messages for needing admin privileges to start manual post sync and for the case of expired nonce
* Added a Cancel button to the manual post import interface.

= 1.5.9 =

* Patched minor CSRF vulnerability

= 1.5.8 =

* The missing 'Already a member? Refresh ..." text label under the locked post interfaces was fixed - now it appears properly
* A PHP warning about Patreon_Wordpress not being available was fixed
* Settings tab resetting & going to dashboard when saving a setting was fixed
* An issue with settings tabs not working correctly was fixed
* An issue with cross site scripting vulnerability was fixed
* Various forms and actions had security nonces added
* Issue with not being able to save some options in the options page was fixed. (Post sync options etc)
* Fixed a potential warning in the locked post interface

= 1.5.7 =

* Fixed an issue with day count showing 0 or negative amount of days when locking post types/categories/taxonomies with 'Show after X days'
* Updated core function to avoid requiring admin privileges breaking wp cli or frontend pages
* Fixed a potential PHP warning about tier title
* Fixed a potential PHP warning when upgrading
* Improved license checking
* Updated button and widgets plugin

= 1.5.6 =

* Added extra sanitization against cross-site script attacks

= 1.5.5 =

* Fixed a bug that could prevent WP cli used in managed hosting services from failing in certain tasks
* Addressed a PHP warning
* Addressed a minor security issue
* Renamed "Custom patron only banner" label in post editor to "Sneak Peek" for more clarity.

= 1.5.4 =

* Fixed an issue with final screen of the setup wizard not displaying properly
* Fixed documentation and quickstart links not working in final setup wizard screen
* Added aria labels for screenreaders for accessibility
* Fixed an issue in which the app icon was not displaying in Patreon login/pledge confirmation screen. Now it should work after reconnecting the site to Patreon.
* Added link to Codebard Patreon campaign
* Removed now unneeded api tab in settings
* Fixed various PHP warnings
* Better handling of current user's pledge

= 1.5.3 =

* Fixed an issue that prevented patron only content shortcode from working. Using partial post locking with ppp_patron_only now should work without creating any error.
* Fixed an issue that prevented non-patron only content shortcode from working. Showing content to non-patrons with ppp_non_patron_only now should work without creating any error.
* Code that generated PHP warnings was fixed.

= 1.5.2 =

* Added new filter vars for enabling upcoming unlock action logging feature
* From PW: Modified lock or not filter to feed more variables to functions.
* From PW: Added and calculated relevant variables during unlock process
* From PW: Added a check for the timestamp of saved patron info
* From PW: Now uses the saved patron info if the timestamp is within 2 seconds of current Unix time and does not call the API
* From PW: Now saves the timestamp of the time when a user has returned from any Patreon flow
* From PW: getPatreonUser now checks for that timestamp in order to decide whether to call the api or not

= 1.5.1 =

* Improved handling of pledge checking - now declined patrons should have the grace period that is applied at patreon.com. This will improve content unlocking and reduce the number of patrons not being able to access content that they qualify for
* Locked content interface text updated to accommodate all currencies
* Included from PW: Made currency sign selection a text input instead of select
* Included from PW: Modified the currency sign option to be currency sign at the front of the amount
* Included from PW: Added a currency sign option to be used at the end of the amount
* Included from PW: All text updated to use the currency sign that is saved in options. $ if default.
* Included from PW: Added call throttling to api calls to avoid spamming of the api by zombie or faulty sites
* Included from PW: Added throttled-return handling to relevant functions
* Included from PW: Added callouts for easy access to plugin upgrade

= 1.5.0 =

* Included all required plugins inside the plugin itself. This will make it easier to install and update the plugin. Recommended.
* Now it needs one less step to complete the setup
* Made compatible with the required plugins if the required plugins are installed separately. The plugin will work in either case and fall back to the included versions if those other plugins are not present. This will prevent functionality and Patreon features from being broken in the case of missing plugins.
* Updated the priority of the Advanced Locking metabox. This will make it easier to find and use.
* Update in included library: An issue with image locking that affected thumbnail size images fixed
* Update in included libraries: Patron Content Manager addon notice hidden if Patron Plugin Pro is active - Patron Plugin Pro handles the PCM notice now

= 1.4.9 =

* Content drip locking added. Now content can be locked for lifetime pledge to allow content drip.
* Added locked post banner text to be shown to non patrons when post is locked with content drip
* Added locked post banner text to be shown to non-qualifying patrons when post is locked with content drip
* Added post footer text to be shown to qualifying patrons when post is locked with content drip
* Now overrides the tier title with $ amount if there are no tiers. This will address various PHP Warnings/Notices that were appearing on dev sites or error logs.
* Address a PHP notice/warning while filtering flow link.
* Removed now unused patreon_nonce var. This should address various login problems.
* Fixed a potential issue with 'Support at Patreon' post button from Buttons plugin being shown to qualifying patrons in unlocked posts.
* Added knowledgebase links to advanced locking methods.

= 1.4.8 =

* Added compatibility with PW's new post sync wizard screens
* Fixed a minor issue with a PHP warning about wp_version

= 1.4.7 =

* Added compatibility with Paid Memberships Pro to allow unlocking PMP gated content via Patreon
* Added compatibility with Paid Memberships Pro to allow unlocking Patreon gated content via PMP
* Made 'Become a Patron' button at the end of posts to be hidden when a post is gated with PMP
* Fixed issue with slashes being added to summaries added in "Patron-only Post Summary in Post Listing Heading" option in Content Locking section
* Modified JavaScript code to reduce chances of interfering with any other plugin's JS code.
* Modified JavaScript code to reduce chances of interfering with any other plugin's JS code.

= 1.4.6 =

* Date based locking or date based showing now allows gating for dates up to 5 years in the future

= 1.4.5 =

* Worked around  WP 5.3 bug that causes a PHP notice that stems from an issue in WP itself.

= 1.4.4 =

* Addressed PHP submenu notice error in WP 5.3
* Updated widget and post button link construction logic
* Better decision on which link to use.
* Made Author widget to go to author's profile if exists

= 1.4.3 =

* Multi line custom patrong greetings now work.

= 1.4.2 =

* Saved greeting for non patrons is loaded properly after switching back and forth in between different tier greetings. Before it loaded default greeting as opposed to saved one.

= 1.4.1 =

* Tier dropdown for Custom Patron Greeting widget made to work with text mode in tier message editor
* Now downloads and installs Patreon WordPress from WP repo

= 1.4.0 =

* An advanced widget, Custom Patron Greeting widget that allows site owners to show customized greetings/messages to their patrons based on their tier was added

= 1.3.9 =

* An issue causing errors and redirections during setup wizard's Patreon connection phase was fixed

= 1.3.8 =

* Content locking options updated to become intuitive and provide easy way to save the selected locking option
* Your creator profile url and page name are now synchronized with Patreon WordPress settings
* Patron Pro will now avoid gating content if you have not connected your site to Patreon
* utm parameters are added to creator profile links

= 1.3.7 =

* Now automatically sets your Patreon profile url for button and widgets

= 1.3.6 =

* Made compatible with PW's new easy setup wizard
* Setup wizard screens modified to accommodate new setup flow

= 1.3.5 =

* An issue which caused misidentification of VIP users, leading them to see higher tiers content was fixed

= 1.3.4 =

* A major bug causing login lock to not work for normal user/pass logins for users who registered via Patreon before, was fixed.
* Login lock now places users on pledge flow so that they can pledge and auto login easily.
* Creator profile url was appearing as %%creator_url%% in locked post interface. This was fixed.
* Patron Pro now auto-fills your profile url if you have not entered your profile url in Quickstart settings, this fixes 404 problems with 'Become a Patron' button.
* If you turned 'Put users directly to Patron Pipeline when they click a "be our patron" button' setting on, now it uses a $1 pledge amount to make them patrons.
* A bug was causing issues with admin-side notices from the plugin. This was fixed.

= 1.3.3 =

* A minor setup bug which caused error message when installing the plugin in PHP 7.1 and 7.2 sites was fixed.
* An issue which caused after update notices not to be dismissible in some installations was fixed.

= 1.3.2 =

* Notable bug which caused lifetime pledge of patrons to not get recognized during post lock/show decisions was fixed. Now if a patron which satisfies the lifetime pledge requirement you set for a post views the post, s/he will get access to it.
* Empty space was generated by custom banner code even in cases there was no custom banner. Now the code for custom banner will appear only when there is any custom banner of any sort.
* Display logic for custom locked post banners improved. Now if its set, it shows Custom sitewide PW banner first, then overrides it with Patron Pro banner if its set, and then overwrites it with custom banner set in the post editor for that post if it is set. No banner is shown if none of these are present.
* Custom Patreon banner for the post metabox was moved to side in order to have it display in Gutenberg editor and classic editor at the same time.
* Now tier name required to view the post is shown instead of the $ level in the interface on locked posts.

= 1.3.1 =

* Manual excerpt capability for sneak peek feature added
* Nested shortcodes should now work

= 1.3.0 =

* Category, tag, custom taxonomy locking feature added
* Background color selection added for locked post excerpts
* Content locking section revamped
* Age countdown fixed for age locked posts
* Login lock feature now recognizes VIP and custom level users
* ***patreonlevelrequirement*** variable made work with custom text for locked post excerpts

= 1.2.7 =

* Locked excerpts can now be locked for $ level
* jQuery modal interface added to allow easy entry of $ level when locking excerpts
* Non-patrons only shortcode added. Allows showing parts of posts to non-patrons only (ads etc)
* Buttons for non-patron only shortcode added to visual and text editor (classic)
* Major bug that prevented login lock feature from working was fixed

= 1.2.6 =

* Now provides VIP user and custom $ level user features
* VIP and Custom $ level users now have specific valid patron footers that tell them they access the content because they are special
* Priority of Patron Pro meta boxes in post editor set to default so they wont get ahead of normal WP post editor boxes
* Patron Widgets Plugin's post button now made to be hidden if the user is a valid patron viewing a locked content since there is no point to show already paying patrons a call to action for patronage

= 1.2.5 =

* Plugin installer wizard now reports errors if plugin processes failed due to server/site configuration
* A bug which caused site-wide custom banner and post-specific custom banner to not appear was fixed
* Added option that allows controlling alignment of banners in post listings
* Defaulted horizontal alignment of banners in post listings to left instead of earlier center - to be compatible with majority of themes
* Added an option to show/hide buttons in banners in post listings
* Defaulted the buttons in banners in post listings to be hidden

= 1.2.4 =

* Implemented a plugin installer/updater/configurator
* Plugin will check if any needed plugins in the bundle are not installed, missing or wrong version, and disable itself and warn the site owner
* Setup wizard now will auto-install/update/configure needed plugins

= 1.2.3 =

* Fixed an issue where plugin was changing excerpt lengths

= 1.2.2 =

* Now checks for presence of required plugins, and warns the site owner and disables itself to prevent site errors

= 1.2.1 =

* Fixed harmless but annoying meta-printing debug code bug that caused post meta to be listed in post editor

= 1.2.0 =

* Now compatible with new API v2 features
* A bug preventing advanced post locking options from being removed from post was fixed 
* Now uses and modifies new API v2 related text for patron status
* Post metabox priority made default to prevent it from appearing over WP post editor post metabox
* Numerous small fixes

= 1.1.3 =

* An option to control sneak peek length added for locked posts. 
* Excerpts before locked posts option renamed to Sneak Peek.

= 1.1.2 =

* Login locking feature that allows you to lock logins to only patrons
* Add/remove user role exemptions to login lock feature
* Patron-only Content Notification Heading for Entire Post no longer adds slashes to the content

= 1.1.1 =

* Important issue that prevented saving language customizations and using them was fixed

= 1.1.0 =

* Compatible with Patreon's upcoming API v2
* Bug with advanced post locking options being deleted when post is saved without any change fixed

= 1.0.9 =

* New feature that shows post excerpts before locked posts - formattable

= 1.0.8 =

* Now shortcodes are applied inside Patron only snippet shortcode
* Now there is only a single login with Patreon button in login forms
* Tested to work with new Image locking functionality

= 1.0.7 =

* Advanced Locking options now available for Single Posts/Pages (including custom)
* "This content is for Patrons pledging " notice now removed from non-locked content

= 1.0.6 =

* Locking last (x) post types feature with pledge level
* Showing last (x) post types feature with pledge level
* Locking post types by post age feature with pledge level
* Locking post types by post date feature with pledge level
* Showing post types by post age feature with pledge level
* Plugin now enables locking of Pages
* New valid patron footer says how many days until post is locked if lock posts by age is set for the post type

= 1.0.5 =

* Users must update Patreon WordPress plugin manually before updating to this version
* Implemented new Patreon interface
* Plugin now automatically puts users into patron pipeline, makes them patron, and brings them back to content to be viewed
* Now Patreon Core, Patreon Core Custom, Patron Plugin Pro Custom and Custom Post Banners are all usable
* New post locking logic
* Fixed interface bugs
* Fixed locking bugs
* Fixed login bugs

= 1.0.4 =

* Major bugfix non-English (en-US) language sites and Out of Memory errors

= 1.0.3 =

* Major bugfix with utm_source parameter not being accepted by Patreon - a must update or URLS wont work!

= 1.0.3 =

* Major bugfix with utm_source parameter not being accepted by Patreon - a must update or URLS wont work!

= 1.0.2 =

* Minor bugfixes

= 1.0.1 =

* Minor bugfixes

= 1.0.0 =

* Initial release!
