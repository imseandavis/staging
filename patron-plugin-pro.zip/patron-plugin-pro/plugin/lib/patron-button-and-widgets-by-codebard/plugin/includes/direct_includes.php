<?php

/* This include is for functions and directives that need to be loaded outside class structure */



?>