<hr width="100%">
	
<?php


$this->display_addons();



?>


<hr width="100%">
	
<br><br>