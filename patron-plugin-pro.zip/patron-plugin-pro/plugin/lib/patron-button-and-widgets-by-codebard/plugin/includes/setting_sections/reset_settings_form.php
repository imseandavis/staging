		<form method="post" action="{***admin_page_url***}admin.php?page=settings_{***id***}">
			<input type="submit" value="  {%%%reset_options%%%}  " style="float:left;"   aria-label="Reset options">
			<input type="hidden" name="{***id***}_action" value="reset_options">
			<input type="hidden" name="{***id***}_tab" value="{***tab***}">
		</form>