<br /><br /><div class="cb_p6_a1_install_plugins_vector"><img src="<?php echo $this->internal['plugin_url'] ?>images/Install-1.png" border="0" /></div><?php


if( 
	get_option('patreon-client-id') != '' AND
	get_option('patreon-client-secret') != '' AND
	get_option('patreon-creators-access-token') != '' AND
	get_option('patreon-creators-refresh-token') != ''

) {
	
	// Patreon client details seem to have been set up. Lets move to the last stage
	
?>



<div class="cb_p6_a1_setup_wizard_text"><h1 class="cb_p6_a1_setup_wizard_heading">Super! Your site seems to have been connected to Patreon already!</h1>You seem to have connected your site to Patreon already. That's great - we can just finish the installation now.
<br>
<form method="post" action="<?php echo $this->internal['admin_url'].'admin.php?page=setup_wizard_'.$this->internal['id'].'&'.$this->internal['prefix'].'setup_stage=2'; ?>">
	<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Finish installation"  aria-label="Finish installation"></p>
	</form>
</div>


<?php	
	
}

else {
	
if ( isset( $this->opt['last_operation_result_key'] ) AND $this->opt['last_operation_result_key'] == 'error_auto_parsing_credentials_failed' ) {
	
	echo '<div class="cb_p6_a1_setup_wizard_text">'.$this->lang['error_auto_parsing_credentials_failed'].'</div>';
	
	
}


?>


<h1 class="cb_p6_a1_setup_wizard_heading">Let's connect your site to Patreon</h1>

<div class="cb_p6_a1_setup_wizard_text">By connecting your site to Patreon, you can bring Patreon features to your website & post member-only content at your website to increase your patrons and monthly revenue. We will now take you to Patreon in order to automatically connect your site. Please make sure you are <a href="https://www.patreon.com/login?utm_source=' . urlencode( site_url() ) . '&utm_medium=patron_plugin_pro&utm_campaign=&utm_content=setup_wizard_screen_0_creator_login_link&utm_term=" target="_blank"  style="text-decoration: none;"  aria-label="Click to log in if you arent already logged into Patreon">logged in</a> to your creator account at Patreon before starting, or <a href="https://www.patreon.com/signup?ru=%2Fcreate?utm_source=' . urlencode( site_url() ) . '&utm_medium=patron_plugin_pro&utm_campaign=&utm_content=setup_wizard_screen_0_creator_signup_link&utm_term=" target="_blank" style="text-decoration: none;"  aria-label="Click to register if you dont yet have a Patreon account">register here</a> if you don't already have a creator account.'</div>
	


<div class="<?php echo $this->internal['prefix'];?>settings">
	<?php
			$requirements_check = Patreon_Compatibility::check_requirements();
			$requirement_notices = '';
			
			if ( is_array( $requirements_check ) AND count( $requirements_check ) > 0 ) {
				$requirement_notices .= PATREON_ENSURE_REQUIREMENTS_MET;
				foreach ( $requirements_check as $key => $value ) {
					$requirement_notices .= '&bull; ' . Patreon_Frontend::$messages_map[$requirements_check[$key]].'<br />';
				}
			}

			$config_info = Patreon_Wordpress::collect_app_info();
			$config_input = '';
			
			foreach ( $config_info as $key => $value ) {
				$config_input .= '<input type="hidden" name="' . $key . '" value="' . $config_info[$key] . '" />';

			}
			
			$setup_message = PATREON_SETUP_INITIAL_MESSAGE;
			
			if ( isset( $_REQUEST['patreon_message'] ) AND $_REQUEST['patreon_message'] != '' ) {
				$setup_message = Patreon_Frontend::$messages_map[$_REQUEST['patreon_message']];

			}

			// Create state var needed for identifying connection attempt
			
			$state = array(
				'patreon_action' => 'connect_site',			
			);

			echo '<div id="patreon_setup_screen">';
	
			$api_endpoint = "https://www.patreon.com/oauth2/";	
						
			echo '<div id="patreon_setup_content">' . $requirement_notices . '<form style="display:block;" method="get" action="'. $api_endpoint .'register-client-creation"><p class="submit" style="margin-top: 10px;"><input type="submit" name="submit" id="submit" class="button button-large button-primary" value="Let\'s start!"  aria-label="Lets start"></p>' . $config_input . '<input type="hidden" name="client_id" value="' . PATREON_PLUGIN_CLIENT_ID . '" /><input type="hidden" name="redirect_uri" value="' . site_url() . '/patreon-authorization/' . '" /><input type="hidden" name="state" value="' . urlencode( base64_encode( json_encode( $state ) ) ) . '" /><input type="hidden" name="scopes" value="w:identity.clients" /><input type="hidden" name="response_type" value="code" /></form></div>';
					
			echo '</div>';
			
	?>
			
</div>

	
	
<?php

	
	
	
}

?>