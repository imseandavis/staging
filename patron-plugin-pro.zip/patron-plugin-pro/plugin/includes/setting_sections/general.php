<?php

$old_error_reporting = error_reporting(0);


echo $this->do_admin_settings_form_header($tab);



echo '<h2>'.$this->lang['option_title_organization_name'].'</h2>';
echo '<div class="'.$this->internal['prefix'].'option_info">'.$this->lang['option_info_org_name'].'</div>';
echo '<input type="text" name="opt[org_name]" value="'.$this->opt['org_name'].'">';


if($this->opt['assign_tickets_to_admins']=='yes')
{
	$assign_tickets_to_admins_checked_yes=" CHECKED";
}
else
{
	$assign_tickets_to_admins_checked_no=" CHECKED";
}

echo '<h2>'.$this->lang['option_title_assign_tickets_to_admins'].'</h2>';
echo '<div class="'.$this->internal['prefix'].'option_info">'.$this->lang['option_info_assign_tickets_to_admins'].'</div>';

echo $this->lang['yes'].' <input type="radio" name="opt[assign_tickets_to_admins]" value="yes"'.$assign_tickets_to_admins_checked_yes.'>'.$this->lang['no'].' <input type="radio" name="opt[assign_tickets_to_admins]" value="no"'.$assign_tickets_to_admins_checked_no.'>';



$this->do_setting_section_additional_settings($tab);

echo $this->do_admin_settings_form_footer($tab);


error_reporting($old_error_reporting);

?>