<br /><br /><div class="cb_p6_a1_install_plugins_vector"><img src="<?php echo $this->internal['plugin_url'] ?>images/Install-0.png" border="0" /></div><?php

// Exception - remove old Patreon WordPress 

$this->check_remove_old_pw();

$required_plugins = $this->required_plugins();



if( ( is_array( $required_plugins ) AND count( $required_plugins ) > 0 ) ) {
	// If no plugin missing or wrong version, move to step 2
?>


<div class="cb_p6_a1_setup_wizard_text"><h1 class="cb_p6_a1_setup_wizard_heading">Let's setup <?php echo $this->lang['plugin_name']; ?>!</h1>We will now auto-install and configure the below plugins which are needed for <?php echo $this->lang['plugin_name']; ?> to function:



<div class="cb_p6_a1_setup_wizard_required_plugins">
<?php 
	
	foreach( $required_plugins as $key => $value ) {
		
		echo $required_plugins[$key]['name'].' '.$required_plugins[$key]['version'];
		echo '<br>';
		
	}
	
?>
</div>
Don't worry! We will figure it out automatically: If you have any of those plugins missing, with the wrong version or not activated, we will automatically fix that!
<div id="cb_p6_a1_install_update_plugin_results">Please click below button to start</div>
<form id="cb_p6_a1_ajax_plugin_install_form" method="post" action="<?php echo $this->internal['admin_url'].'admin.php?page=setup_wizard_'.$this->internal['id']; ?>" ajax_target_div="cb_p6_a1_install_update_plugin_results">
	<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Setup and configure plugins" aria-label="Setup and configure plugins"></p>
	<input type="hidden" name="wp_ajax_<?php echo $this->internal['prefix'].'install_update_plugins'; ?>" value="1" />
	<input type="hidden" name="<?php echo $this->internal['prefix'].'setup_stage'; ?>" value="0" />
</form>
</div>
<?php
}
else {
?>

<div class="cb_p6_a1_setup_wizard_text"><h1 class="cb_p6_a1_setup_wizard_heading">Great! We have all the required plugins</h1>
All of the required plugins for Patron Pro package are installed and are the correct version! Now lets configure Patron Pro!
<br clear="both" />
<form method="post" action="<?php echo $this->internal['admin_url'].'admin.php?page=setup_wizard_'.$this->internal['id'].'&'.$this->internal['prefix'].'setup_stage=1'; ?>">
	<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Skip to configuration!"></p>
	</form>
	
</div>
<?php
}

?>
