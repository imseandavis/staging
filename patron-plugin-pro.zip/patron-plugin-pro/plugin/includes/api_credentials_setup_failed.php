<?php


?>
<div class="cb_p6_setup_wizard_big_heading" style="max-width : 500px; line-height:1;display:block;"><?php echo $this->lang['api_credentials_failed_during_setup'];?></div>
<div class="cb_p6_setup_wizard_big_heading" style="max-width : 500px; line-height:1;display:block;"><?php echo $this->lang['api_credentials_failed_during_setup_support'];?></div>
	
<?php


?>