<div id="{***prefix***}admin_settings_form_footer">

<button type="submit" class="cb_p6_admin_button"  aria-label="Save">{%%%save%%%}</button>
			<input type="hidden" name="{***id***}_action" value="save_settings">
			<input type="hidden" name="{***id***}_tab" value="{***tab***}">
			<input type="hidden" name="cb_plugins_nonce_save_settings" value="{***form_nonce***}">

		</form>

</div>