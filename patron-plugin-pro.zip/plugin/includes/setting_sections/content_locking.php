<?php

global $cb_p6;

$old_error_reporting = error_reporting(0);

echo $cb_p6->do_admin_settings_form_header();

$excerpt_banner_align_left_checked = '';
$excerpt_banner_align_center_checked = '';
$excerpt_banner_align_right_checked = '';
$patron_only_heading_bold_checked_yes = '';
$patron_only_heading_bold_checked_no = '';
$patron_only_heading_bold_checked_no = '';
$custom_excerpt_listing_button_show_on = '';
$custom_excerpt_listing_button_show_off = '';
$patron_only_excerpt_heading_bold_checked_yes = '';
$patron_only_excerpt_heading_bold_checked_no = '';			
$patron_only_excerpt_listing_heading_bold_checked_yes = '';			
$patron_only_excerpt_listing_heading_bold_checked_no = '';			
$only_ppp_banners_checked_yes = '';			
$only_ppp_banners_checked_no = '';			
$custom_button_new_window_checked_yes = '';			
$custom_button_new_window_checked_no = '';			
$custom_excerpt_button_new_window_checked_yes = '';			
$custom_excerpt_button_new_window_checked_no = '';			
$custom_excerpt_listing_button_new_window_checked_yes = '';			
$custom_excerpt_listing_button_new_window_checked_no = '';			
$put_users_to_pipeline_checked_yes = '';			
$put_users_to_pipeline_checked_no = '';			
$gate_excerpts_in_listings_checked_yes = '';			
$gate_excerpts_in_listings_checked_no = '';			
$show_excerpts_for_locked_post_yes = '';			
$show_excerpts_for_locked_post_no = '';			
$entire_site_patron_only_checked_yes = '';			
$entire_site_patron_only_checked_no = '';			


if($this->opt['content_locking']['custom_patron_only_heading']!='')
{
	
	$current_heading = $this->opt['content_locking']['custom_patron_only_heading'];
}
else
{
	
	$current_heading = $this->lang['this_content_is_patron_only'];
	
}

if($this->opt['content_locking']['custom_patron_only_excerpt_heading']!='')
{
	
	$current_excerpt_heading = $this->opt['content_locking']['custom_patron_only_excerpt_heading'];
}
else
{
	
	$current_excerpt_heading = $this->lang['this_content_is_patron_only_excerpt'];
	
}
if($this->opt['content_locking']['custom_patron_only_excerpt_listing_heading']!='')
{
	
	$current_excerpt_listing_heading = stripslashes( $this->opt['content_locking']['custom_patron_only_excerpt_listing_heading'] );
}
else
{
	
	$current_excerpt_listing_heading = '';
	
}



if(isset($this->opt[$tab]['custom_excerpt_listing_banner_wrapper_horizontal_alignment']) AND $this->opt[$tab]['custom_excerpt_listing_banner_wrapper_horizontal_alignment']=='left') { 
	$excerpt_banner_align_left_checked=" CHECKED";
}
if(isset($this->opt[$tab]['custom_excerpt_listing_banner_wrapper_horizontal_alignment']) AND $this->opt[$tab]['custom_excerpt_listing_banner_wrapper_horizontal_alignment']=='center') { 
	$excerpt_banner_align_center_checked=" CHECKED";
}
if(isset($this->opt[$tab]['custom_excerpt_listing_banner_wrapper_horizontal_alignment']) AND $this->opt[$tab]['custom_excerpt_listing_banner_wrapper_horizontal_alignment']=='right') { 
	$excerpt_banner_align_right_checked=" CHECKED";
}

if(isset($this->opt[$tab]['patron_only_heading_bold']) AND $this->opt[$tab]['patron_only_heading_bold']=='yes')
{

	$patron_only_heading_bold_checked_yes=" CHECKED";

}
else
{
	$patron_only_heading_bold_checked_no=" CHECKED";	
}

if(isset($this->opt[$tab]['custom_excerpt_listing_button_show']) AND $this->opt[$tab]['custom_excerpt_listing_button_show']=='yes')
{

	$custom_excerpt_listing_button_show_on=" CHECKED";

}
else
{
	$custom_excerpt_listing_button_show_off=" CHECKED";	
}
		

if(isset($this->opt[$tab]['patron_only_excerpt_heading_bold']) AND $this->opt[$tab]['patron_only_excerpt_heading_bold']=='yes')
{

	$patron_only_excerpt_heading_bold_checked_yes=" CHECKED";

}
else
{
	$patron_only_excerpt_heading_bold_checked_no=" CHECKED";	
}



if(isset($this->opt[$tab]['patron_only_excerpt_listing_heading_bold']) AND $this->opt[$tab]['patron_only_excerpt_listing_heading_bold']=='yes')
{

	$patron_only_excerpt_listing_heading_bold_checked_yes=" CHECKED";

}
else
{
	$patron_only_excerpt_listing_heading_bold_checked_no=" CHECKED";	
}


		
if(isset($this->opt[$tab]['only_ppp_banners']) AND $this->opt[$tab]['only_ppp_banners']=='yes')
{

	$only_ppp_banners_checked_yes=" CHECKED";

}
else
{
	$only_ppp_banners_checked_no=" CHECKED";	
}
		
if(isset($this->opt[$tab]['custom_button_new_window']) AND $this->opt[$tab]['custom_button_new_window']=='yes')
{

	$custom_button_new_window_checked_yes=" CHECKED";

}
else
{
	$custom_button_new_window_checked_no=" CHECKED";	
}


if(isset($this->opt[$tab]['custom_excerpt_button_new_window']) AND $this->opt[$tab]['custom_excerpt_button_new_window']=='yes')
{

	$custom_excerpt_button_new_window_checked_yes=" CHECKED";

}
else
{
	$custom_excerpt_button_new_window_checked_no=" CHECKED";	
}
		
if(isset($this->opt[$tab]['custom_excerpt_listing_button_new_window']) AND $this->opt[$tab]['custom_excerpt_listing_button_new_window']=='yes')
{

	$custom_excerpt_listing_button_new_window_checked_yes=" CHECKED";

}
else
{
	$custom_excerpt_listing_button_new_window_checked_no=" CHECKED";	
}

if(isset($this->opt[$tab]['put_users_to_pipeline']) AND $this->opt[$tab]['put_users_to_pipeline']=='yes')
{

	$put_users_to_pipeline_checked_yes=" CHECKED";

}
else
{
	$put_users_to_pipeline_checked_no=" CHECKED";	
}


if(isset($this->opt[$tab]['entire_site_patron_only']) AND $this->opt[$tab]['entire_site_patron_only']=='yes')
{

	$entire_site_patron_only_checked_yes=" CHECKED";

}
else
{
	$entire_site_patron_only_checked_no=" CHECKED";	
}


if(isset($this->opt[$tab]['gate_excerpts_in_listings']) AND $this->opt[$tab]['gate_excerpts_in_listings']=='yes')
{

	$gate_excerpts_in_listings_checked_yes=" CHECKED";

}
else
{
	$gate_excerpts_in_listings_checked_no=" CHECKED";	
}

if(isset($this->opt[$tab]['show_excerpts_for_locked_post']) AND $this->opt[$tab]['show_excerpts_for_locked_post']=='yes')
{

	$show_excerpts_for_locked_post_yes=" CHECKED";

}
else
{
	$show_excerpts_for_locked_post_no=" CHECKED";	
}

$post_types = get_post_types();
$select='';
foreach($post_types as $key => $value)
{
	$obj=get_post_type_object($key);
	$select.='<option value="'.$key.'">'.$obj->labels->singular_name.'</option>';

}
$select_remove='';
$current_post_types='';

if( isset($this->opt['content_locking']['gated_post_types'])
	AND is_array($this->opt['content_locking']['gated_post_types'])
	AND count($this->opt['content_locking']['gated_post_types'])>0
) {
		
	$gated_post_types = $this->opt['content_locking']['gated_post_types'];
	
	foreach( $gated_post_types as $key => $value)
	{
		
		$post_type_info = get_post_type_object($key);
		
		if( isset($gated_post_types[$key] )
		AND is_array($gated_post_types[$key])
		AND count($gated_post_types[$key])>0
		) {
			
			$gated_taxonomy = $gated_post_types[$key];
									
			foreach($gated_taxonomy as $key_taxonomy => $value_taxonomy) {
				
				$taxonomy_info = get_taxonomy( $key_taxonomy);
			
				if( isset($gated_taxonomy[$key_taxonomy] )
				AND is_array($gated_taxonomy[$key_taxonomy])
				AND count($gated_taxonomy[$key_taxonomy])>0
				) {
					
					$gated_taxonomy_item = $gated_taxonomy[$key_taxonomy];
					
					foreach($gated_taxonomy_item as $key_taxonomy_item => $value_taxonomy_item) {
				
						$taxonomy_item_info = get_term_by('slug', $key_taxonomy_item, $key_taxonomy, ARRAY_A );
						
						// Translate certain names into human readable formats:
						
						// In future the below repeating code must be moved into its function:
						
						$taxonomy_name = 'All';
						
						if ( isset( $taxonomy_info->labels->singular_name ) ) {
							$taxonomy_name = $taxonomy_info->labels->singular_name;
						}
						
						$taxonomy_item_name = 'All';
			
						if ( isset( $taxonomy_item_info['name'] ) ) {
							$taxonomy_item_name = $taxonomy_item_info['name'];
						}
														
						$select_remove.='<option value="'.$key.'-CTERMSEP-'.$key_taxonomy.'-CTERMSEP-'.$key_taxonomy_item.'">' . $post_type_info->labels->name. ' -> '. $taxonomy_name . ' -> '. $taxonomy_item_name.'</option>';
						
						$all_notice = '';
						
						if ( $taxonomy_name == 'All' AND $taxonomy_item_name == 'All' ) {
							$all_notice = ' (This rule will cause all '.$post_type_info->labels->name.' to be locked)';
						}
						
						$current_post_types.='<div class="cb_p6_a1_locked_post_small_title">'.$post_type_info->labels->name. ' -> '. $taxonomy_name . ' -> '. $taxonomy_item_name . $all_notice.'</div>';
						
						if($gated_taxonomy_item[$key_taxonomy_item]['locking_type']=='all') {
							$current_post_types.='Lock All';
						}

						if($gated_taxonomy_item[$key_taxonomy_item]['locking_type']=='last_x') {
							$current_post_types.='Lock last '.$gated_taxonomy_item[$key_taxonomy_item]['locking_variable'];
						}
						if($gated_taxonomy_item[$key_taxonomy_item]['locking_type']=='show_last_x') {
							$current_post_types.='Show last '.$gated_taxonomy_item[$key_taxonomy_item]['locking_variable'];
						}
						if($gated_taxonomy_item[$key_taxonomy_item]['locking_type']=='age') {
							$current_post_types.='Lock all older than '.$gated_taxonomy_item[$key_taxonomy_item]['locking_variable'].' days';
						}
						if($gated_taxonomy_item[$key_taxonomy_item]['locking_type']=='show_age') {
							$current_post_types.='Show all older than '.$gated_taxonomy_item[$key_taxonomy_item]['locking_variable'].' days to anyone';
						}
						if($gated_taxonomy_item[$key_taxonomy_item]['locking_type']=='date') {
							
							$start_date_string = $gated_taxonomy_item[$key_taxonomy_item]['start_date']['day'].' '.date('F', @mktime(0, 0, 0, $gated_taxonomy_item[$key_taxonomy_item]['start_date']['month'], 10)).' '.$gated_taxonomy_item[$key_taxonomy_item]['start_date']['year'];
							
							$end_date_string = $gated_taxonomy_item[$key_taxonomy_item]['end_date']['day'].' '.date('F', @mktime(0, 0, 0, $gated_taxonomy_item[$key_taxonomy_item]['end_date']['month'], 10)).' '.$gated_taxonomy_item[$key_taxonomy_item]['end_date']['year'];
							
							foreach($gated_taxonomy_item[$key_taxonomy_item]['start_date'] as $date => $value) {
								
								if($gated_taxonomy_item[$key_taxonomy_item]['start_date'][$date]=='any')
								{
									$start_date_string = 'any date';
								}
							}
							foreach($gated_taxonomy_item[$key_taxonomy_item]['end_date'] as $date => $value) {
								if($gated_taxonomy_item[$key_taxonomy_item]['end_date'][$date]=='any')
								{
									$end_date_string = 'any date';
								}
							}
							
							$current_post_types.='Lock starting from ';
							$current_post_types.= $start_date_string;
							$current_post_types.= ' to ';
							$current_post_types.= $end_date_string;
							
						}
						
						$current_post_types.=' - Min $'.$gated_taxonomy_item[$key_taxonomy_item]['locking_value'].' pledge<br>';								
					
					}
				}
			}
		}
	}
}

	
?>
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Make post types Patron only <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span><a href="https://codebard.com/patron-plugin-pro-documentation/manual/how-to-lock-entire-posts-from-any-post-type" target="_blank"><span class="dashicons dashicons-editor-help cb_p2_settiong_section_help_icon"></span></a></h3> 
			</div>
			<!-- Admin section start -->
			<div class="cb_p6_a1_admin_section">
			
			
				You can add any post type to a list of Patron Only posts. When you add a post type, all content from that type will be patron-only.
				<br><br>
				<select id="cb_p6_a1_post_locking_format_post" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][add_post_type_to_gate]"><option selected value="nochange">Select Post Type</option><?php echo $select; ?></select>
				
				
				<select id="cb_p6_a1_post_locking_format_taxonomy" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][post_locking_format_taxonomy]">
				<option selected value="all">All</option>
				
				</select>
				<select id="cb_p6_a1_post_locking_format_taxonomy_item" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][post_locking_format_taxonomy_item]">
				<option selected value="all">All</option>
				
				</select>
				
				<select id="cb_p6_a1_post_locking_format_option_toggle" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][post_locking_format]">
					
					<option selected value="none">Select how to lock</option>
					<option value="all">Lock all posts of this type</option>
					<option value="last_x">Lock last (X) posts of this type</option>
					<option value="show_last_x">Show only last (X) posts of this type</option>
					<option value="date">Lock by start and/or end date</option>
					<option value="age">Lock these posts after (X) days</option>
					<option value="show_age">Show these posts after (X) days</option>
				
				</select>
					
				<div id="cb_p6_a1_post_locking_format_last_x" class="cb_p6_a1_locking_format_selector">
					<b>Lock last <input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][lock_last_x_posts]" value="10"> posts of this type</b>
				
				</div>
				<div id="cb_p6_a1_post_locking_format_show_last_x" class="cb_p6_a1_locking_format_selector">
					<b>Show last <input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][show_last_x_posts]" value="10"> posts of this type</b>
				
				</div>
				
				<div id="cb_p6_a1_post_locking_format_date" class="cb_p6_a1_locking_format_selector">
					<?php
					
						echo $this->make_date_select(
			
							$date_args=array(
								'title'=>$this->lang['start_date'],
								'default_month_value'=>'any',
								'default_year_value'=>'any',
								'default_day_value'=>'any',
								'default_day_label'=>'Any',
								'default_year_label'=>'Any',
								'default_month_label'=>'Any',
								'select_name_day'=>'opt['.$this->internal['prefix'].'content_locking][start_day]',
								'select_name_month'=>'opt['.$this->internal['prefix'].'content_locking][start_month]',
								'select_name_year'=>'opt['.$this->internal['prefix'].'content_locking][start_year]',
				
							)
						);
						echo '<br>';
						echo $this->make_date_select(
			
							$date_args=array(
								'title'=>$this->lang['end_date'],
								'default_month_value'=>'any',
								'default_year_value'=>'any',
								'default_day_value'=>'any',
								'default_day_label'=>'Any',
								'default_year_label'=>'Any',
								'default_month_label'=>'Any',
								'select_name_day'=>'opt['.$this->internal['prefix'].'content_locking][end_day]',
								'select_name_month'=>'opt['.$this->internal['prefix'].'content_locking][end_month]',
								'select_name_year'=>'opt['.$this->internal['prefix'].'content_locking][end_year]',
				
							)
						);
			
					?>
				</div>
					
				<div id="cb_p6_a1_post_locking_format_age" class="cb_p6_a1_locking_format_selector">
					<b>Lock these posts <input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][lock_after_x_days]" value="7" aria-label="The count of days to lock these posts after"> days after they are published</b>
				
				</div>	
				<div id="cb_p6_a1_post_locking_format_show_age" class="cb_p6_a1_locking_format_selector">
					<b>Show these posts to anyone <input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][show_after_x_days]" value="7" aria-label="The count of days to show these posts after"> days after they are published</b>
				</div>		
				
				<div id="cb_p6_a1_post_locking_value">
					
					<b>Minimum $ value to be able to see the posts </b><input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][post_locking_value]" value="0">
					<br /><br />
					<button type="submit" class="cb_p6_admin_button" aria-label="Add post type to gating">Add post type to gating</button>
				</div>
				
				
				<h3>Make a post type, category or custom taxonomy public again (remove Patron only)</h3>
				Remove a post type or category you marked Patron only before from the list of Patron only post types. 
				
				<br><br>
				<select id="cb_p6_a1_remove_post_type_from_gating" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][remove_post_type_from_gate]"  aria-label="Select the post type to remove from gating"><option selected value="nochange">No Change</option><?php echo $select_remove; ?></select>
				<br><br>
				<div id="cb_p6_a1_remove_post_type_from_gating_button">
				<button type="submit" class="cb_p6_admin_button"  aria-label="Remove this post type from gating">Remove post type from gating</button>
				<br><br>
				</div>
				<span style="font-size: 100%">Current Patron only Post Types:<br><br><b><?php echo substr($current_post_types,0,-2); ?></b></span>
				<br><br>

				<h3>Make entire site Patron-only</h3>
				If 'Yes', entire content in your site will be made patron-only. This includes all post types. 
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][entire_site_patron_only]" value="yes"<?php echo $entire_site_patron_only_checked_yes; ?>  aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][entire_site_patron_only]" value="no"<?php echo $entire_site_patron_only_checked_no; ?>  aria-label="Yes">
			
			
			</div>
			<!-- Admin section end -->
			
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Allow only patrons to login <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span><a href="https://codebard.com/patron-plugin-pro-documentation/manual/how-to-allow-only-your-patrons-to-log-in-to-your-site"  aria-label="Click here to read the manual page for allowing only patrons to log into your site" target="_blank"><span class="dashicons dashicons-editor-help cb_p2_settiong_section_help_icon"></span></a></h3> 
			</div>
			<!-- Admin section start -->
			<div class="cb_p6_a1_admin_section">
				
				If you set a $ amount below, only patrons with pledges at or over that amount will be able to log in to your site and use any site feature - this includes logging in, profile sections, comments - everything that requires a login.  
				<br><br>
				$<input type="text" size="4" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][only_patrons_with_amount]" value="<?php echo $this->opt[$tab]['only_patrons_with_amount'] ?>"  aria-label="The $ pledge amount that patrons must have to be able to log in" >
				<br><br>
				
				<?php 

						$select_remove_2='';
						$currently_permitted_user_roles_list='';
						$user_role_select ='';
						
						global $wp_roles;
						$roles = $wp_roles->get_names();

						if( isset($this->opt['content_locking']['always_login_allowed_roles'])
							AND is_array($this->opt['content_locking']['always_login_allowed_roles'])
							AND count($this->opt['content_locking']['always_login_allowed_roles'])>0
							) {
							
							foreach($roles as $key => $value) {
								$user_role_select .= '<option value="'.$key.'">'.$roles[$key].'</option>';
								
								if(isset($this->opt['content_locking']['always_login_allowed_roles'][$key])) {
									
									$currently_permitted_user_roles_list .= $roles[$key].', ';
									$select_remove_2 .= '<option value="'.$key.'">'.$roles[$key].'</option>';
									
								}
							
							}
						}	
						
				?>
				
				<h3>Add user role to permitted login list</h3>
				If you choose to lock the site as patrons only, you can let users with a given user role to be exempt from being patrons and allow them to log in directly. 
				<br><br>
				<select name="opt[<?php echo $this->internal['prefix'].$tab; ?>][add_user_role_to_login_lock_exemptions]"><option selected value="nochange"  aria-label="Add user role to make exempt from login lock" >Select User Role</option><?php echo $user_role_select; ?></select>			
				
				
				<h3>Remove user role from permitted login list</h3>
				You can remove any user role from below list to have them login only if they are patrons. Please note - Administrator and Editor roles should always be allowed. If you aren't exactly sure what these settings are, its best to leave them alone - default settings would work for almost all sites.
				
				<br><br>
				<select name="opt[<?php echo $this->internal['prefix'].$tab; ?>][remove_user_role_from_login_lock_exemptions]"><option selected value="nochange" aria-label="Remove user role from login lock exemption list">No Change</option><?php echo $select_remove_2; ?></select>
				<br><br>
				
				<span style="font-size: 100%">Currently always-permitted user roles :<br><br><b><?php echo substr($currently_permitted_user_roles_list,0,-2); ?></b></span>
				<br><br>
				
				<h3>Only patrons can login message 1</h3>
				If you set Only patrons can log in and fill in any message to below box, this message will be shown before the $ amount in the message that tells users that only patrons can log in. If empty, default message part 1 from existing language files will be used.
				<br><br>
				<input type="text" size="40" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][only_patrons_login_message_1]" value="<?php echo $this->opt[$tab]['only_patrons_login_message_1'] ?>" aria-label="The message to show users about login lock before the $ amount requirement" >
				<br><br>	
				<h3>Only patrons can login message 2</h3>
				If you set Only patrons can log in and fill in any message to below box, this message will be shown after the $ amount in the message that tells users that only patrons can log in. If empty, default message part 2 from existing language files will be used.
				<br><br>
				<input type="text" size="40" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][only_patrons_login_message_2]" value="<?php echo $this->opt[$tab]['only_patrons_login_message_2'] ?>"  aria-label="The message to show users about login lock after the $ amount requirement" >
				<br><br>	
				
			</div>
				
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Protect Summaries for Patron only Posts in Post Listings <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span><a href="https://codebard.com/patron-plugin-pro-documentation/manual/protecting-excerpts-in-listings" target="_blank" aria-label="Click here to read the manual page about protecting excerpts in your post listings" ><span class="dashicons dashicons-editor-help cb_p2_settiong_section_help_icon"></span></a></h3> 
			</div>
			<!-- Admin section start -->
			<div class="cb_p6_a1_admin_section">
		
				If you mark a post Patron-only, visitors can still see the summary from that post in Post listings. Choose yes if you would like to gate the summaries too. If you would like summaries appear in listings as a 'preview' of your posts, then choose no. Remember to make WordPress show only excerpts in listings instead of full posts <a href="<?php echo get_site_url().'/wp-admin/options-reading.php'; ?>" target="_blank">here</a>. (For Each article in a Feed, show Summary instead of Full Text)
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][gate_excerpts_in_listings]" value="yes"<?php echo $gate_excerpts_in_listings_checked_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][gate_excerpts_in_listings]" value="no"<?php echo $gate_excerpts_in_listings_checked_no; ?> aria-label="No">
				
			</div>
			
			
<?php
		$get_creator_id = get_option('patreon-creator-id',true);
		
		if($get_creator_id!='')
		{
?>
		
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Put users directly to Patron Pipeline when they click a "be our patron" button <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span><a href="https://codebard.com/patron-plugin-pro-documentation/manual/putting-visitors-directly-to-patron-pipeline" target="_blank" aria-label="Click to read the manual page about putting visitors directly to pledge flow when they click Patreon post button or widget buttons."><span class="dashicons dashicons-editor-help cb_p2_settiong_section_help_icon"></span></a></h3> 
			</div>
			<!-- Admin section start -->
			<div class="cb_p6_a1_admin_section">
			
				If 'Yes', users will be directly sent to patron pipeline at patreon. If no, users will be sent to your profile. This option will only appear and work if you have correctly entered your user id in settings.		
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][put_users_to_pipeline]" value="yes"<?php echo $put_users_to_pipeline_checked_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][put_users_to_pipeline]" value="no"<?php echo $put_users_to_pipeline_checked_no; ?> aria-label="No">
			</div>	
			<!-- Admin section end -->
<?php } ?>


			
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Use Patron Plugin Pro banners instead of default Patreon banners everywhere <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span></h3> 
			</div>
			<!-- Admin section start -->
			<div class="cb_p6_a1_admin_section">
			
				If 'Yes', Patron Plugin Pro banners and buttons will be used for every locked content, instead of default banners. Exception is the posts which you added custom banners - if any post has custom banner, it will be used instead of Patron Plugin Pro banners.			
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][only_ppp_banners]" value="yes"<?php echo $only_ppp_banners_checked_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][only_ppp_banners]" value="no"<?php echo $only_ppp_banners_checked_no; ?> aria-label="No">
				
			</div>	
			<!-- Admin section end -->
			
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Sneak Peek before locked posts <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span><a href="https://codebard.com/patron-plugin-pro-documentation/manual/how-to-show-teasers-before-locked-posts" target="_blank" aria-label="Click to read the manual page about showing sneak peeks before locked posts"><span class="dashicons dashicons-editor-help cb_p2_settiong_section_help_icon"></span></a></h3> 
			</div>
			<!-- Admin section start -->			
			<div class="cb_p6_a1_admin_section">
			
				If 'Yes', a short post excerpt from the post will be shown before a locked post. You can customize the excerpt below.			
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][show_excerpts_for_locked_post]" value="yes"<?php echo $show_excerpts_for_locked_post_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][show_excerpts_for_locked_post]" value="no"<?php echo $show_excerpts_for_locked_post_no; ?> aria-label="No">
				<br><br>	
				
				
				<h3>Size of the sneak peek before locked posts</h3>
				Sneak peek before locked posts will be this big, in words. If you dont enter any value or zero, the sneak peek will be made 35 words by default.		
				
				<br><br>
				<input type="text" size="10" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][excerpt_before_locked_post_format_length]" value="<?php echo $this->opt[$tab]['excerpt_before_locked_post_format_length'] ?>" aria-label="The word count to set the sneak peek length to">
				<br><br>
				
				
				<h3>Format of Sneak Peek shown before locked posts</h3>
				If you turned on "Sneak Peek before locked posts" at the top, you can modify how the excerpt that will appear. {%%show_excerpt_here%%} is the placeholder where the excerpt will show up. So if you put a text saying "Hello! here is a preview of this patron only post!" and then below that insert {%%show_excerpt_here%%}, then excerpt will show under that sentence. You can use HTML.
				
				<?php 
				
					$cb_p6_a1_text_editor_settings = array(
						'teeny' => true,
						'textarea_rows' => 5,
						'tabindex' => 1,
						'textarea_name' => 'opt['.$this->internal['prefix'].$tab.'][excerpt_before_locked_post_format]',
						
						'quicktags' => array( 'buttons' => 'strong,em,del,ul,ol,li,close' ),
					);
					echo '<div style="width : 100%;max-width:500px;display:block;">';
					wp_editor(stripslashes($this->opt['content_locking']['excerpt_before_locked_post_format']), 'excerpt_before_locked_post_format', $cb_p6_a1_text_editor_settings);
					echo '</div>';

				?>

			</div>	
			<!-- Admin section end -->
			

			</div>	
			<!-- Admin section end -->
			
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Patron-only sections inside posts <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span><a href="https://codebard.com/patron-plugin-pro-documentation/manual/how-to-lock-parts-of-a-post-or-content" target="_blank" aria-label="Click to read the manual page about locking parts of your post content"><span class="dashicons dashicons-editor-help cb_p2_settiong_section_help_icon"></span></a></h3> 
			</div>
			<!-- Admin section start -->			
			<div class="cb_p6_a1_admin_section">
				
				<h3>Patron-only Section Notification background</h3>
				You can change the background color for Patron only sections inside your posts below.
				<br><br>
				
				<input type="text" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_background_color]" value="<?php echo $this->opt[$tab]['patron_only_excerpt_background_color']; ?>" id="cb_p6_a1_patron_only_excerpt_background_color" class="cb_p6_a1_color_field"  aria-label="The background color for the the call to action in the patron-only parts of your posts" >
												
				<h3>Patron-only Section Notification Heading</h3>
				This is the heading shown over the button shown for sections inside content that are marked patron only. These sections/excerpts are parts of your content which you mark as for patrons only using the "Patron Only" buttons in your post editor. You can have multiple patron-only sections in a post. Change this to a different text if you wish. If you enter ***patreonlevelrequirement***, it will be replaced with $ value for the requirement for the post. Ie if you put '$***patreonlevelrequirement***', it will be $4 for a post set to 4 dollars of level. 
				<br><br>
				<textarea style="width : 100%;max-width:500px;min-height : 80px; height :auto;" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_patron_only_excerpt_heading]" aria-label="The heading for the the call to action in the patron-only parts of your posts"><?php echo $current_excerpt_heading; ?></textarea>
				
			
				<h3>Bold Patron-only Section Notification Heading</h3>
				If 'Yes', Patron-only Section Notification Heading will be in a bold font. If no, normal.
				
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_heading_bold]" value="yes"<?php echo $patron_only_excerpt_heading_bold_checked_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_heading_bold]" value="no"<?php echo $patron_only_excerpt_heading_bold_checked_no; ?> aria-label="No">
				<br><br>
							
			
				<h3>Size of the Patron-only Section Notification</h3>
				You can set the font size of patron only section notification. Experiment with this value if you think heading should be larger or smaller. 
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_heading_font_size]" value="<?php echo $this->opt[$tab]['patron_only_excerpt_heading_font_size']; ?>" aria-label="The size of the heading for the call to action in the patron-only parts in your post content">
			

				<h3>Patron-only Section Notification Button/Banner opens in New window</h3>
				If 'Yes', buttons/banners in Patron-Only Section Notification will open Patreon in a new window.
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_button_new_window]" value="yes"<?php echo $custom_excerpt_button_new_window_checked_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_button_new_window]" value="no"<?php echo $custom_excerpt_button_new_window_checked_no; ?> aria-label="No">
				<br><br>	
				
				
				<h3>Use a custom button/banner for Patron-only Section Notification</h3>
				You can use a custom image for the notification users see for patron only excerpts. Just click on below field to be taken to your WordPress media library to select your button or upload a new button and select that one. After selecting your button, save options and your new custom button will be made active.
				
				<br><br>			
				 <input class="cb_p6_a1_file_upload" type="text" id="opt[<?php echo $tab; ?>]_custom_excerpt_button" size="36" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_button]" value="<?php echo $this->opt[$tab]['custom_excerpt_button']; ?>"  aria-label="Upload a file here if you want to use a custom image for the button in the call to action for the patron only parts in your post content" /> <a href="" class="cb_p6_clear_prevfield">Clear</a>
				<br><br>
				Current custom button/banner :
				<br>
			<?php
				if($this->opt[$tab]['custom_excerpt_button']!='')
				{
					echo '<a rel="nofollow"'.@$new_window.' href="'.@$url.'" aria-label="Click to see the current custom button/banner"><img style="margin-top: 10px;margin-bottom: 10px;max-width:50px;width:100%;height:auto;" src="'.$this->opt[$tab]['custom_excerpt_button'].'"></a>';				
					
				}
			?>
				<h3>Width for your custom button/banner for Patron-only Section</h3>
				You can set the width for your custom button if you want to have it display larger or smaller. Height will be adjusted automatically. If you leave this empty, default width of 200px will be used - something close to official Patreon button. Experiment with this value if you think your custom button is larger/smaller than you wish. 
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_button_width]" value="<?php echo $this->opt[$tab]['custom_excerpt_button_width']; ?>"  aria-label="Width in pixel for your custom button">			
			
					<h3>Patron-only Section Notification Button/Banner Margin</h3>
				This is the space around the button/banner. 
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_button_margin]" value="<?php echo $this->opt[$tab]['custom_excerpt_button_margin']; ?>" aria-label="Margin in pixel for your custom button">
				
					<h3>Patron-only Section Padding</h3>
				This is the space inside the notification box.
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_padding]" value="<?php echo $this->opt[$tab]['patron_only_excerpt_padding']; ?>" aria-label="The spacing around the content in the notification box">

			
			</div>	
			<!-- Admin section end -->
			
	
			<div class="cb_p6_a1_admin_section_header cb_p6_a1_toggle_admin_sections" target="cb_p6_a1_post_locking_options">
				<h3>Customize Notifications for Summaries for Patron-only posts in Post listings <span class="dashicons dashicons-arrow-down-alt2 cb_p2_settiong_section_toggle_icon"></span><a href="https://codebard.com/patron-plugin-pro-documentation/manual/customize-notifications-for-summaries-for-patron-only-posts-in-post-listings" target="_blank"><span class="dashicons dashicons-editor-help cb_p2_settiong_section_help_icon"></span></a></h3> 
			</div>
			<!-- Admin section start -->			
			<div class="cb_p6_a1_admin_section">		
				
				<h3>Patron-only Post Summary in Post Listing Heading</h3>
				If you turned on "Protect Summaries in Listings" at the top, you can modify the notification that appears for summaries in listings. Change this to a different text if you wish.
				<br><br>
				<textarea style="width : 100%;max-width:500px;min-height : 80px; height :auto;" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_patron_only_excerpt_listing_heading]"  aria-label="Custom text for notifications/call-to-action in the patron-only parts of your posts"><?php echo $current_excerpt_listing_heading; ?></textarea>
				
			
				<h3>Bold Patron-only Post Summary in Post Listing Heading</h3>
				If 'Yes', Patron-only Summary Listing Notification Heading will be in a bold font. If no, normal.
				
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_listing_heading_bold]" value="yes"<?php echo $patron_only_excerpt_listing_heading_bold_checked_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_listing_heading_bold]" value="no"<?php echo $patron_only_excerpt_listing_heading_bold_checked_no; ?> aria-label="No">
				<br><br>		
							
			
				<h3>Size of the Patron-only Post Summary in Post Listing Notification</h3>
				You can set the font size of patron only notifications in summaries in post listings. Experiment with this value if you think heading should be larger or smaller. 
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_listing_heading_font_size]" value="<?php echo $this->opt[$tab]['patron_only_excerpt_listing_heading_font_size']; ?>" aria-label="Font size for the headings in the notifications/callouts in patron only parts of your posts">
			

				<h3>Patron-only Post Summary in Post Listing Button/Banner opens in New window</h3>
				If 'Yes', buttons/banners in Patron-only Post Summary in Post Listing will open Patreon in a new window.
				<br><br>
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_button_new_window]" value="yes"<?php echo $custom_excerpt_button_new_window_checked_yes; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_button_new_window]" value="no"<?php echo $custom_excerpt_button_new_window_checked_no; ?> aria-label="No">
				<br><br>	
				
				
			<h3>Use a custom button/banner for Patron-only Post Summary in Post Listing</h3>
				You can use a custom image for the notification users see for patron only post summaries. Just click on below field to be taken to your WordPress media library to select your button or upload a new button and select that one. After selecting your button, save options and your new custom button will be made active.
				
				<br><br>			
				 <input class="cb_p6_a1_file_upload" type="text" id="opt[<?php echo $tab; ?>]_custom_excerpt_listing_button" size="36" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_button]" value="<?php echo $this->opt[$tab]['custom_excerpt_listing_button']; ?>"  aria-label="Select a custom image to use as button from your WP media library" /> <a href="" class="cb_p6_clear_prevfield">Clear</a>
			<br><br>
			Current custom button/banner :
			<br>
			<?php
				if($this->opt[$tab]['custom_excerpt_listing_button']!='')
				{
					echo '<a rel="nofollow"'.@$new_window.' href="'.@$url.'"><img style="margin-top: 10px;margin-bottom: 10px;max-width:50px;width:100%;height:auto;" src="'.$this->opt[$tab]['custom_excerpt_listing_button'].'" aria-label="See the current custom button"></a>';				
					
				}
			?>
				<h3>Width for your custom button/banner for Patron-only Excerpt Listings</h3>
				You can set the width for your custom button if you want to have it display larger or smaller. Height will be adjusted automatically. If you leave this empty, default width of 200px will be used - something close to official Patreon button. Experiment with this value if you think your custom button is larger/smaller than you wish. 
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_button_width]" value="<?php echo $this->opt[$tab]['custom_excerpt_listing_button_width']; ?>" aria-label="The custom pixel width for your custom button. Optional.">

				<h3>Patron-only Excerpt Listing Notification Alignment</h3>
				This is how should the items inside the banner be aligned. Default is left, and text and images should be aligned left. If you set it to center, all will be centered. With right, well...
				<br><br>
				
				Left <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_banner_wrapper_horizontal_alignment]" value="left"<?php echo $excerpt_banner_align_left_checked; ?> aria-label="Left"> Center <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_banner_wrapper_horizontal_alignment]" value="center"<?php echo $excerpt_banner_align_center_checked; ?> aria-label="Center"> <br><br>
				Right <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_banner_wrapper_horizontal_alignment]" value="right"<?php echo $excerpt_banner_align_right_checked; ?> aria-label="Right">
				<br><br>
				
				<h3>Show button in Patron-only Excerpt Listings</h3>
				This allows you to turn the button in banners inside post listings on or off. Default is off, because many themes have a 'read more' button and due to this there would appear 2 buttons if this is turned on. But if it fits your theme, you can turn this button on
				<br><br>
				
				Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_button_show]" value="yes"<?php echo $custom_excerpt_listing_button_show_on; ?> aria-label="Yes">
				No <input type="radio" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_button_show]" value="no"<?php echo $custom_excerpt_listing_button_show_off; ?> aria-label="No"> <br><br>
				
			
				<h3>Patron-only Excerpt Listing Notification Button/Banner Margin</h3>
				This is the space around the button/banner. 
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][custom_excerpt_listing_button_margin]" value="<?php echo $this->opt[$tab]['custom_excerpt_listing_button_margin']; ?>" aria-label="The margin around your button/banner">
				
					<h3>Patron-only Excerpt Listing Padding</h3>
				This is the space inside the notification box.
				<br><br>
				<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_only_excerpt_listing_padding]" value="<?php echo $this->opt[$tab]['patron_only_excerpt_listing_padding']; ?>" aria-label="The spacing inside the notification box">
			
			</div>	
			<!-- Admin section end -->
			
		
<?php



$cb_p6->do_setting_section_additional_settings($tab);

echo $cb_p6->do_admin_settings_form_footer($tab);

error_reporting($old_error_reporting);

?>

	<div style="display:block;clear:both;"></div>