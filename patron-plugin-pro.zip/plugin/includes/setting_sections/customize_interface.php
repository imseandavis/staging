<?php

global $cb_p6;

$old_error_reporting = error_reporting(0);

echo $cb_p6->do_admin_settings_form_header();

		
		if($this->opt['content_locking']['custom_patron_only_heading']!='')
		{
			
			$current_heading = $this->opt['content_locking']['custom_patron_only_heading'];
		}
		else
		{
			
			$current_heading = $this->lang['this_content_is_patron_only'];
			
		}
		
		

		if(isset($this->opt[$tab]['patron_only_heading_bold']) AND $this->opt[$tab]['patron_only_heading_bold']=='yes')
		{
		
			$patron_only_heading_bold_checked_yes=" CHECKED";
		
		}
		else
		{
			$patron_only_heading_bold_checked_no=" CHECKED";	
		}
				
		//echo $this->make_date_select($date_args);
?>	

	<h1>Customize Main Banner</h1><a href="" class="cb_p6_a1_toggle" target="cb_p6_a1_settings_section_customize_interface_main_banner">Show/Hide this section</a>
		<div id="cb_p6_a1_settings_section_customize_interface_main_banner" class="cb_p6_a1_toggle">
			<h3>Patron-only Content Notification Heading for Entire Post</h3>
			This is the heading shown over the button when a visitor checks out a Patron only post and s/he is not a Patron. This works only in any content you marked 'Patron Only' by using the checkbox that is in post editor. Change this to a different text if you wish. If you enter ***patreonlevelrequirement***, it will be replaced with $ value for the requirement for the post. Ie if you put '$***patreonlevelrequirement***', it will be $4 for a post set to 4 dollars of level.
			<br><br>
	
			<?php wp_editor(stripslashes($current_heading) ,'patreon_custom_universal_banner',array('textarea_name'=>'opt['.$this->internal['prefix'].'content_locking][custom_patron_only_heading]','textarea_rows'=>5)); ?>
			
		
			<h3>Bold Patron-only Content Notification Heading for Entire Post</h3>
			If 'Yes', Patron-only Content Notification Heading will be in a bold font. If no, normal.
			
			<br><br>
			Yes <input type="radio" name="opt[<?php echo $this->internal['prefix'].'content_locking'; ?>][patron_only_heading_bold]" value="yes"<?php echo $patron_only_heading_bold_checked_yes; ?> aria-label="Yes">
			No <input type="radio" name="opt[<?php echo $this->internal['prefix'].'content_locking'; ?>][patron_only_heading_bold]" value="no"<?php echo $patron_only_heading_bold_checked_no; ?> aria-label="No">
			<br><br>		
			
			<h3>Size of the Patron-only Content Notification for Entire Post</h3>
			You can set the font size of patron only content notification. Experiment with this value if you think heading should be larger or smaller. 
			<br><br>
			<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].'content_locking'; ?>][patron_only_heading_font_size]" value="<?php echo $this->opt['content_locking']['patron_only_heading_font_size']; ?>" aria-label="The font size of the notification">
		
			
			
		<h3>Use a custom button/banner for Patron-only Content Notification for Entire Post</h3>
			You can use a custom image for the notification users see if they check out a Patron-only post! Just click on below field to be taken to your WordPress media library to select your button or upload a new button and select that one. After selecting your button, save options and your new custom button will be made active.
			
			<br><br>			
			 <input class="cb_p6_a1_file_upload" type="text" id="opt[<?php echo $tab; ?>]_custom_button" size="36" name="opt[<?php echo $this->internal['prefix'].'content_locking'; ?>][custom_button]" value="<?php echo $this->opt['content_locking']['custom_button']; ?>"  aria-label="Upload file to use for the custom button/banner" /> <a href="" class="cb_p6_clear_prevfield" aria-label="Clear">Clear</a>
		<br><br>
		Current custom button/banner :
		<br>
		<?php
			if($this->opt['content_locking']['custom_button']!='')
			{
				echo '<a rel="nofollow"'.@$new_window.' href="'.@$url.'" aria-label="Click to see the current custom button/banner"><img style="margin-top: 10px;margin-bottom: 10px;max-width:50px;width:100%;height:auto;" src="'.$this->opt['content_locking']['custom_button'].'"></a>';				
				
			}
		?>
			<h3>Width for your custom button/banner for Patron-only Content Notification for Entire Post</h3>
			You can set the width for your custom button if you want to have it display larger or smaller. Height will be adjusted automatically. If you leave this empty, default width of 200px will be used - something close to official Patreon button. Experiment with this value if you think your custom button is larger/smaller than you wish. 
			<br><br>
			<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].'content_locking'; ?>][custom_button_width]" value="<?php echo $this->opt['content_locking']['custom_button_width']; ?>" aria-label="The width for your custom button. Optional.">
			
				<h3>Patron-only Content Notification Padding</h3>
			This is the space inside the notification box.
			<br><br>
			<input type="text" style="width : 50px" name="opt[<?php echo $this->internal['prefix'].'content_locking'; ?>][patron_only_content_padding]" value="<?php echo $this->opt['content_locking']['patron_only_content_padding']; ?>" aria-label="The spacing around the content in the notification box">
	
	<br><br>
	<a href="" class="cb_p6_a1_toggle" target="cb_p6_a1_settings_section_customize_interface_main_banner">Hide</a>
		</div>
			<hr width="100%" />
			
		<br><br>
		
<?php



$cb_p6->do_setting_section_additional_settings($tab);

echo $cb_p6->do_admin_settings_form_footer($tab);


error_reporting($old_error_reporting);

?>		