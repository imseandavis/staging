<?php

global $cb_p6;

echo $cb_p6->do_admin_settings_form_header();

if(isset($this->opt['last_operation_result']) AND $this->internal['setup_is_being_done']==false)
{

	echo '<div class="'.$this->internal['prefix'].'last_operation_result">'.$this->opt['last_operation_result'].'</div>';
	unset($this->opt['last_operation_result']);
	$this->update_opt();
}
?>
<br>
<a href="#" class="cb_p6_a1_toggle" target="cb_p6_a1_get_api_credentials"><?php echo $this->lang['learn_how_to_get_credentials']; ?></a>
<div id="cb_p6_a1_get_api_credentials"><h3>Step 1 - <a href="https://www.patreon.com/portal/registration/register-clients" target="_blank">Please visit this page at Patreon</a>, click "CREATE CLIENT" and copy/paste the values shown below to the textboxes in matching fields</h3>

<b>For "App Name (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo preg_replace("/[^A-Za-z0-9 ]/", '',get_bloginfo('name')); ?>">
<br><br>
<b>For "Description (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo preg_replace("/[^A-Za-z0-9 ]/", '',get_bloginfo('name')); ?> app">
<br><br>
<b>For "Author or Company Name (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo preg_replace("/[^A-Za-z0-9 ]/", '',get_bloginfo('name')); ?>">
<br><br>

<?php

    $get_site_url    = site_url(); 
    $site_url_parts = parse_url( $get_site_url ); 
	$site_domain   = $site_url_parts['host'];

?>

<b>For "Company Domain (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo $site_domain; ?>">


<br><br>
<b>For "Icon URL (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo $this->internal['plugin_url'].'plugin/templates/default/app_icon.png'; ?>">
<br><br>


<b>For "Privacy Policy URL"</b>
<br>
You can skip this particular field if you wish. If not, enter the privacy policy url of your site. Its not required. If unsure, just skip it.

<br><br>
<b>For "Terms of Service URL"</b>
<br>
You can skip this particular field if you wish. If not, enter the terms of service url of your site. Its not required. If unsure, just skip it.

<br><br>
<b>For "Redirect URIs (required, valid URLs with http or https, separated by spaces)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo $get_site_url.'/patreon-authorization/'; ?>">


<h3>Step 2 - The orange button that says "CREATE CLIENT" or "UPDATE CLIENT" should be clickable now. Click that button to save the newly entered fields at Patreon.</h3>
<h3>Step 3- The window should disapper (click on an empty area if it doesn't). You should see a listing which has the name you just entered. Please click the down arrow icon on the right of that listing. When some seemingly garbled characters appear above a "REFRESH TOKEN" button, please copy/paste that entire text in starting with "App Name" and ending with garbled characters above "REFRESH TOKEN" button. Paste the text you copied into the textbox below (including the first text Client ID and the last garbled characters, as they are).</h3>
<?php

echo '<textarea style="width:100%;max-width : 500px; height:auto;min-height: 80px;" name="opt['.$this->internal['prefix'].'client_details_input]"></textarea>';




?>

<h3>Step 4 - Click "Save" below. And after the form is saved, log out of your WordPress site, and then visit your WordPress site's login page again and choose "Log in with Patreon" and log in with Patreon just once. This is so that the plugin can get your Creator ID to use in buttons to send your visitors directly to patron pipeline and its important. After this, you can log out and log in with your WordPress admin as normal.</h3>

<button type="submit" class="cb_p6_admin_button"><?php echo $this->lang['save']; ?></button>



</div>
<?php


echo '<h2>'.$this->lang['patreon_client_id'].'</h2>';
echo '<div class="'.$this->internal['prefix'].'option_info">'.$this->lang['option_info_patreon_client_id'].'</div>';
echo '<input type="text" size="80" name="opt['.$this->internal['prefix'].'patreon_client_id]" value="'.get_option('patreon-client-id',true).'">';


echo '<h2>'.$this->lang['patreon_client_secret'].'</h2>';
echo '<div class="'.$this->internal['prefix'].'option_info">'.$this->lang['option_info_patreon_client_secret'].'</div>';
echo '<input type="text" size="80" name="opt['.$this->internal['prefix'].'patreon_client_secret]" value="'.get_option('patreon-client-secret',true).'">';


echo '<h2>'.$this->lang['patreon_creator_access_token'].'</h2>';
echo '<div class="'.$this->internal['prefix'].'option_info">'.$this->lang['option_info_creator_access_token'].'</div>';
echo '<input type="text" size="80" name="opt['.$this->internal['prefix'].'patreon_creator_access_token]" value="'.get_option('patreon-creators-access-token',true).'">';


echo '<h2>'.$this->lang['patreon_creator_refresh_token'].'</h2>';
echo '<div class="'.$this->internal['prefix'].'option_info">'.$this->lang['option_info_creator_refresh_token'].'</div>';
echo '<input type="text" size="80" name="opt['.$this->internal['prefix'].'patreon_creator_refresh_token]" value="'.get_option('patreon-creators-refresh-token',true).'">';




$cb_p6->do_setting_section_additional_settings($tab);

echo $cb_p6->do_admin_settings_form_footer($tab);

?>