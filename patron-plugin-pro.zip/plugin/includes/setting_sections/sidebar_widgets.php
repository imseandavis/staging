<?php

$old_error_reporting = error_reporting(0);


$tab=$_REQUEST['cb_p6_tab'];


		if(isset($this->opt[$tab]['hide_site_widget_on_single_post_page']) AND $this->opt[$tab]['hide_site_widget_on_single_post_page']=='yes')
		{
		
			$hide_site_widget_on_single_post_page_checked_yes=" CHECKED";
		
		}
		else
		{
			$hide_site_widget_on_single_post_page_checked_no=" CHECKED";
				
		
		}
		if(isset($this->opt[$tab]['insert_text_align']) AND $this->opt[$tab]['insert_text_align']=='left')
		{
		
			$widget_insert_text_align_checked_left=" CHECKED";
		
		}
		if(isset($this->opt[$tab]['insert_text_align']) AND $this->opt[$tab]['insert_text_align']=='center')
		{

			$widget_insert_text_align_checked_center=" CHECKED";
		
		}
		if(isset($this->opt[$tab]['insert_text_align']) AND $this->opt[$tab]['insert_text_align']=='right')
		{
		
			$widget_insert_text_align_checked_right=" CHECKED";
		
		}

?>



			<hr>		
<h1>Patron greeting widget</h1>
			<hr>
			<br>This widget allows you to show a custom greeting to your patrons based on their tier level. You can find the widget in your WP admin's Appearance -> Widgets menu. Read how you can use this widget <a href="https://codebard.com/patron-plugin-pro-documentation/manual/how-to-use-custom-patron-greeting-widget" target="_blank">here</a>.
			<br>
			<br>Select a tier to customize the greeting for. For any tier without a custom greeting, default greeting for 'Any patron' is used.
			<br>
			<br><a id="patron_greeting_section"></a>
			<select id="patron_greeting_tier_select" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_greeting_tier_select]"  aria-label="Tier to customize the greeting for"><?php echo str_replace('Everyone', 'Non patrons', Patreon_Wordpress::make_tiers_select( $post )); ?></select>
			<?php
			
			$default_greeting_title = $this->lang['patron_greeting_tier_title_non_patron'];
			$default_greeting_message = $this->lang['patron_greeting_tier_message_non_patron'];
			
			if ( isset( $this->opt['sidebar_widgets']['patron_greeting_tiers'][0]['title'] ) AND $this->opt['sidebar_widgets']['patron_greeting_tiers'][0]['title'] != '' ) {
				$default_greeting_title = $this->opt['sidebar_widgets']['patron_greeting_tiers'][0]['title'];
			}
	
			if ( isset( $this->opt['sidebar_widgets']['patron_greeting_tiers'][0]['message'] ) AND $this->opt['sidebar_widgets']['patron_greeting_tiers'][0]['message'] != '' ) {
				$default_greeting_message = $this->opt['sidebar_widgets']['patron_greeting_tiers'][0]['message'];
			}
	
			$default_greeting_message = nl2br( stripslashes( $default_greeting_message ) );			
			
			?>
			
			<h3>The greeting title for above tier</h3>
			<input id="patron_greeting_tier_title" name="opt[<?php echo $this->internal['prefix'].$tab; ?>][patron_greeting_tier_title]" value="<?php echo $default_greeting_title; ?>" size="50" width="50"  aria-label="The title for the greeting" />
				<br><br>
				Placing {patronname} anywhere in the text above will make patron's name shown there.
		
			<h3>The greeting message for above tier</h3>
			<?php wp_editor( $default_greeting_message, 'patron_greeting_tier_message', array( 'editor_height' => 250, 'textarea_name' => 'opt[' . $this->internal['prefix'] . $tab . '][patron_greeting_tier_message]' )); ?>
			
				<br><br>
				Placing {patronname} anywhere in the text above will make patron's name shown there.
		
<?php


error_reporting($old_error_reporting);



?>