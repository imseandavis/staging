<?php

$this->internal = array_replace_recursive(
	
	
	$this->internal,
	
	array(
		
		'id' => 'cb_p6_a1',
		'prefix' => 'cb_p6_a1_',
		'version' => '1.6.2',
		'plugin_name' => 'Patron Plugin Pro',
		'update_api_url' => 'https://updates.codebard.com',
		'addon_key' => 'patron_plugin_pro',
		'edd_id' => 3284,
		
		'callable_from_request' => array(
			'process_credentials_at_setup' => 1,
			 
		),
			
		
		'calllimits' => array(
		
			'add_admin_menu'=>1,
		),		
		
		'tables'=> array(


		),	
		'data'=> array(


		),	
		

		'meta_tables'=> array(

						
		),	
		
		'post_metas'=> array(
			'marked_patron_only' => '',
			'patron_only_custom_banner' => '',
			'ppp_advanced_post_locking' => '',
			'remove_advanced_post_locking' => '',
						
		),

		'required_plugins'=> array(
			'patreon-connect' => array(
				'name' => 'Patreon WordPress',
				'plugin_name_slug' => 'patreon-connect',
				'slug' => 'patreon-connect/patreon.php',
				'version' => '1.7.8',
				//'source' => 'codebard',
				'source' => 'wprepo',
				'repo_name' => 'WordPress.org',
				'download_url' => 'https://downloads.wordpress.org/plugin/patreon-connect.1.7.8.zip',
				// 'download_url' => 'https://updates.codebard.com/download.php?key=' . md5('patreon-connect.zip').'&license=&item_name='.base64_encode('Patreon WordPress').'&site='.base64_encode(get_site_url()),
			),
			'cb_p6' => array(
				'name' => 'Patron Button & Widgets by CodeBard',
				'plugin_name_slug' => 'patron-button-and-widgets-by-codebard',
				'slug' => 'patron-button-and-widgets-by-codebard/index.php',
				'version' => '2.1.2',
				'source' => 'wprepo',
				'repo_name' => 'WordPress.org',
				'download_url' => 'https://downloads.wordpress.org/plugin/patron-button-and-widgets-by-codebard.2.1.2.zip',
			),

		),
		
	)
	
);


?>