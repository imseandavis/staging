<br /><br /><div class="cb_p6_a1_install_plugins_vector"><img src="<?php echo $this->internal['plugin_url'] ?>images/Install-Final.png" border="0" alt="Installation complete image" /></div><?php

if(!get_option('patreon-creator-id', false))
{
	$this->auto_get_patreon_creator_id();
}


?>

<div class="<?php echo $this->internal['prefix'];?>settings">

	<h1 class="cb_p6_a1_setup_wizard_heading">Great! Patron Plugin Pro is ready!</h1>
	
	<div class="cb_p6_a1_setup_wizard_text">We successfully set up Patron Pro and connected your site to Patreon! Congratulations! You are good to go!</div>
	
			<div id="patreon_success_inserts">
			
				<a href="https://codebard.com/patron-plugin-pro-documentation/getting-started/quickstart" target="_blank" aria-label="Read the quickstart guide"><div class="patreon_success_insert"><div class="patreon_success_insert_logo"><img src="<?php echo $this->internal['plugin_url']; ?>images/Read-quickstart.jpg" alt="Read quickstart guide" border="0" /></div><br clear="both"><div class="patreon_success_insert_heading"><h3>Quickstart guide</h3></div><div class="patreon_success_insert_content"><br clear="both">Click here to read our quickstart guide to kickstart your site</div></div></a>

				<a href="https://codebard.com/patron-plugin-pro-documentation" target="_blank"><div class="patreon_success_insert"><div class="patreon_success_insert_logo"><img src="<?php echo $this->internal['plugin_url']; ?>images/Read-manual.jpg"  aria-label="Read the manual" /></div><br clear="both"><div class="patreon_success_insert_heading"><h3>Manual</h3></div><div class="patreon_success_insert_content"><br clear="both">Read the manual and learn how to use advanced features</div></div></a>
				
				<a href="https://www.patreon.com/codebard/membership" target="_blank" aria-label="Start gating your content"><div class="patreon_success_insert"><div class="patreon_success_insert_logo"><img src="<?php echo $this->internal['plugin_url']; ?>images/Square-Social.png" style="width:150px; height:150px;" /></div><br clear="both"><div class="patreon_success_insert_heading"><h3>Become Patron</h3></div><div class="patreon_success_insert_content"><br clear="both">Become a Codebard patron to get all Patreon plugins & other perks</div></div></a>
				
			</div>
	

	<hr width="100%" />
	<br><br>
	<div class="cb_p6_setup_wizard_small_heading"><?php echo $this->lang['setup_wizard_if_you_have_questions'];?></div>
	
	<br><br>
	<hr width="100%" />
	
	<div class="cb_p6_setup_wizard_big_heading">
	
		<?php echo $this->lang['setup_wizard_keep_in_touch'];?>
	</div>
	
	
	<div class="cb_p6_setup_wizard_two_col" style="max-width : 600px;">
	
		<div class="cb_p6_setup_wizard_col_50" style="text-align : center; max-width : 600px;">
		
			<?php echo $this->lang['setup_wizard_follow_us_on_twitter'];?><br><br><a href="https://twitter.com/codebardcom" class="twitter-follow-button" data-show-count="false" aria-label="Follow at Twitter"><?php echo $this->lang['setup_wizard_twitter_follow_label_prefix'];?> @CodeBard</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
			
		</div>
	
		<div class="cb_p6_setup_wizard_col_50" style="text-align : center;">
		
			Join our update list
			<br><br>
	
			<button class="button button-primary button-large" onclick="window.open('http://codebard.us9.list-manage.com/subscribe?u=5afbc1be9f2ed76070f4b64fd&id=d24515a258');" target="_blank" aria-label="Join the mailing list"><?php echo $this->lang['setup_wizard_join_mailing_list_link_label'];?></button>
		</div>

	</div>
	
	
<?php


?>