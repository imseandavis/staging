<?php


?>

<div class="<?php echo $this->internal['prefix'];?>settings">

	<div id="cb_p6_setup_wizard_header"><a href="https://codebard.com" target="_blank"><img src="<?php echo $this->internal['plugin_url']; ?>images/codebard_very_small.png"></a> <?php echo $this->lang['patron_plugin_pro_label'];?> <?php echo $this->lang['plugin_is_almost_ready'];?></div>

	
		
	
	<div class="cb_p6_setup_wizard_big_heading"><?php echo $this->lang['gotta_get_the_api_credentials'];?></div>
	
	
	<div id="cb_p6_a1_get_api_credentials" style="display:block !important;"><h3>Step 1 - <a href="https://www.patreon.com/portal/registration/register-clients" target="_blank">Please visit this page at Patreon</a>, click "CREATE CLIENT" and copy/paste the values shown below to the textboxes in matching fields</h3>
	<form method="post" action="<?php echo $this->internal['admin_url'].'admin.php?page=settings_cb_p6'; ?>">
	
<b>For "App Name (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo preg_replace("/[^A-Za-z0-9 ]/", '',get_bloginfo('name')); ?>">
<br><br>
<b>For "Description (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo preg_replace("/[^A-Za-z0-9 ]/", '',get_bloginfo('name')); ?> app">
<br><br>
<b>For "Author or Company Name (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo preg_replace("/[^A-Za-z0-9 ]/", '',get_bloginfo('name')); ?>">
<br><br>

<?php

    $get_site_url    = site_url(); 
    $site_url_parts = parse_url( $get_site_url ); 
	$site_domain   = $site_url_parts['host'];

?>

<b>For "Company Domain (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo $site_domain; ?>">


<br><br>
<b>For "Icon URL (required)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo $this->internal['plugin_url'].'plugin/templates/default/app_icon.png'; ?>">
<br><br>


<b>For "Privacy Policy URL"</b>
<br>
You can skip this particular field if you wish. If not, enter the privacy policy url of your site. Its not required. If unsure, just skip it.

<br><br>
<b>For "Terms of Service URL"</b>
<br>
You can skip this particular field if you wish. If not, enter the terms of service url of your site. Its not required. If unsure, just skip it.

<br><br>
<b>For "Redirect URIs (required, valid URLs with http or https, separated by spaces)"</b>
<br>
<input type="text" size="80" onClick="this.setSelectionRange(0, this.value.length)" value="<?php echo $get_site_url.'/patreon-authorization/'; ?>">


<h3>Step 2 - The orange button that says "CREATE CLIENT" or "UPDATE CLIENT" should be clickable now. Click that button to save the newly entered fields at Patreon.</h3>
<h3>Step 3- The window should disapper (click on an empty area if it doesn't). You should see a listing which has the name you just entered. Please click the down arrow icon on the right of that listing. When some seemingly garbled characters appear above a "REFRESH TOKEN" button, please copy/paste that entire text in starting with "App Name" and ending with garbled characters above "REFRESH TOKEN" button. Paste the text you copied into the textbox below (including the first text Client ID and the last garbled characters, as they are).</h3>
<?php

echo '<textarea style="width:100%;max-width : 500px; height:auto;min-height: 80px;" name="opt['.$this->internal['prefix'].'client_details_input]"></textarea>';




?>

<h3>Step 4 - Click "Save" below. Once the credentials are successfully saved, you are all set up! If you encounter any error, you can fill the credentials in Patreon API section of your plugin's admin section. </h3>



<button type="submit" class="cb_p6_admin_button"><?php echo $this->lang['save']; ?></button>

	<input type="hidden" name="<?php echo $this->internal['id'];?>_action" value="process_credentials_at_setup">
	<input type="hidden" name="setup_stage" value="1">
	</form>

</div>

	
	
<?php


?>