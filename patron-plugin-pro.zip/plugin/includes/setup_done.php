<?php

if(!get_option('patreon-creator-id', false))
{
	$this->auto_get_patreon_creator_id();
}
?>

<div class="<?php echo $this->internal['prefix'];?>settings">

	<div id="cb_p6_setup_wizard_header"><a href="https://codebard.com" target="_blank"><img src="<?php echo $this->internal['plugin_url']; ?>images/codebard_very_small.png"></a> <?php echo $this->lang['patron_plugin_pro_label'];?> <?php echo $this->lang['plugin_is_ready'];?></div>

	
		
	
	<div class="cb_p6_setup_wizard_big_heading"><?php echo $this->lang['setup_now_you_can'];?></div>
	
	
	
	
	<div class="cb_p6_setup_wizard_one_col" style="text-align : center;font-size : 100%; max-width : 600px;">
	
			<button class="cb_p6_admin_button" style="width:30%;" onclick="window.open('https://codebard.com/patron-plugin-pro-quickstart-guide');" target="_blank"><?php echo $this->lang['setup_read_quickstart_guide'];?></button>
			<button class="cb_p6_admin_button" style="width:30%;" onclick="window.open('https://codebard.com/patron-plugin-pro-manual');" target="_blank"><?php echo $this->lang['manual_link_label'];?></button>
	
	
			<button class="cb_p6_admin_button"  style="width:30%;" onclick="window.open('<?php echo $this->internal['admin_url'].'admin.php?page=settings_cb_p6'; ?>&cb_p6_tab=content_locking');" target="_blank"><?php echo $this->lang['adjust_content_locking'];?></button>
	

		

	</div>
	<hr width="100%" />
	<div class="cb_p6_setup_wizard_big_heading"><?php echo $this->lang['setup_wizard_done'];?></div>
	<div class="cb_p6_setup_wizard_small_heading"><?php echo $this->lang['setup_wizard_if_you_have_questions'];?></div>
	
	<br><br>
	<hr width="100%" />
	
	<div class="cb_p6_setup_wizard_big_heading">
	
		<?php echo $this->lang['setup_wizard_keep_in_touch'];?>
	</div>
	
	
	<div class="cb_p6_setup_wizard_two_col" style="max-width : 600px;">
	
		<div class="cb_p6_setup_wizard_col_50" style="text-align : center; max-width : 600px;">
		
			<?php echo $this->lang['setup_wizard_follow_us_on_twitter'];?><br><br><a href="https://twitter.com/codebardcom" class="twitter-follow-button" data-show-count="false"><?php echo $this->lang['setup_wizard_twitter_follow_label_prefix'];?> @CodeBard</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
			
		</div>
	
		<div class="cb_p6_setup_wizard_col_50" style="text-align : center;">
		
			<?php echo $this->lang['setup_wizard_join_list']; ?>
			<br><br>
	
			<button class="cb_p6_admin_button" onclick="window.open('http://codebard.us9.list-manage.com/subscribe?u=5afbc1be9f2ed76070f4b64fd&id=d24515a258');" target="_blank"><?php echo $this->lang['setup_wizard_join_mailing_list_link_label'];?></button>
		</div>

	</div>
	
	
<?php


?>