<?php

// commeon functions
include_once( 'general-functions.php' );
include_once( 'general-hooks.php' );

new WP_Ulike_Pro_Front_End_Assets();