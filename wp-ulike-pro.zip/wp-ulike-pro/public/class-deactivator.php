<?php

/**
 * Fired during plugin deactivation
 *
 */

class WP_Ulike_Pro_Deactivator {

	public static function deactivate() {

	}

}