<?php

if (!defined('ABSPATH')) {
    exit;
}

class Account_Locker_DB {
    private string $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'account_locker_activity';
    }

    public function create_tables() {
        global $wpdb;
        
        // Temporarily increase memory limit and execution time
        $this->increase_limits();
        
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            action varchar(255) NOT NULL,
            performed_by bigint(20) NOT NULL,
            timestamp datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY timestamp (timestamp)
        ) $charset_collate;";

        // Use direct query instead of dbDelta for less memory usage
        $wpdb->query($sql);
    }

    private function increase_limits() {
        // Increase memory limit
        $current_limit = ini_get('memory_limit');
        $current_limit_int = wp_convert_hr_to_bytes($current_limit);
        
        if ($current_limit_int < 256 * 1024 * 1024) { // If less than 256MB
            @ini_set('memory_limit', '256M');
        }
        
        // Increase time limit
        @set_time_limit(300); // 5 minutes
        
        // Increase MySQL timeout
        global $wpdb;
        $wpdb->query('SET SESSION wait_timeout=300');
    }

    public function migrate_data_in_chunks($chunk_size = 100) {
        global $wpdb;
        
        $offset = 0;
        $processed = 0;
        
        do {
            // Get users in chunks
            $users = get_users([
                'number' => $chunk_size,
                'offset' => $offset
            ]);
            
            if (empty($users)) {
                break;
            }
            
            foreach ($users as $user) {
                $log = get_user_meta($user->ID, 'account_locker_log', true);
                if (!empty($log) && is_array($log)) {
                    foreach ($log as $entry) {
                        $wpdb->insert(
                            $this->table_name,
                            array(
                                'user_id' => $user->ID,
                                'action' => $entry['action'],
                                'performed_by' => $entry['performed_by'],
                                'timestamp' => $entry['timestamp']
                            ),
                            array('%d', '%s', '%d', '%s')
                        );
                    }
                    // Clean up old data
                    delete_user_meta($user->ID, 'account_locker_log');
                }
                $processed++;
            }
            
            $offset += $chunk_size;
            
            // Free up memory
            wp_cache_flush();
            
        } while (count($users) === $chunk_size);
        
        return $processed;
    }

    public function drop_tables() {
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$this->table_name}");
    }

    public function verify_table(): bool {
        global $wpdb;
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'");
        
        if (!$table_exists) {
            $this->create_tables();
            return $this->verify_table();
        }
        
        return true;
    }
} 