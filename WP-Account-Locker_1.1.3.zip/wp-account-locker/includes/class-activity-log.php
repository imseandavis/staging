<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles logging of account lock/unlock activities
 *
 * @since 1.0.2
 */
class Account_Locker_Activity_Log {

    private int $per_page = 15;
    private string $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'account_locker_activity';
        
        // Verify table exists
        $db = new Account_Locker_DB();
        $db->verify_table();
        
        add_action('admin_menu', array($this, 'add_activity_log_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_log_styles'));
    }

    /**
     * Add activity log to admin menu
     */
    public function add_activity_log_page() {
        add_users_page(
            __('Account Lock Activity Log', 'account-locker'),
            __('Lock Activity', 'account-locker'),
            'manage_options',
            'account-lock-activity',
            array($this, 'render_activity_page')
        );
    }

    /**
     * Enqueue styles for activity log page
     */
    public function enqueue_log_styles($hook) {
        if ('users_page_account-lock-activity' !== $hook) {
            return;
        }

        wp_enqueue_style(
            'account-locker-admin',
            plugin_dir_url(dirname(__FILE__)) . 'css/admin.css',
            array(),
            '1.1.0'
        );
    }

    /**
     * Add activity log to user's meta
     */
    public function log_activity($user_id, $action, $performed_by): bool {
        global $wpdb;
        
        error_log("Attempting to log activity: User: $user_id, Action: $action, Performed by: $performed_by");
        
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'user_id' => $user_id,
                'action' => $action,
                'performed_by' => $performed_by,
                'timestamp' => current_time('mysql')
            ),
            array('%d', '%s', '%d', '%s')
        );

        if ($result === false) {
            error_log('Account Locker: Failed to log activity - ' . $wpdb->last_error);
            return false;
        }
        
        error_log('Activity logged successfully');
        return true;
    }

    /**
     * Render the activity log page
     */
    public function render_activity_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'account-locker'));
        }
        
        wp_nonce_field('account_locker_activity_log', 'activity_log_nonce');

        // Get filters
        $action_filter = isset($_GET['filter_action']) ? sanitize_text_field($_GET['filter_action']) : '';
        $user_filter = isset($_GET['filter_user']) ? intval($_GET['filter_user']) : 0;
        $performed_by_filter = isset($_GET['filter_performed_by']) ? sanitize_text_field($_GET['filter_performed_by']) : '';
        $date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
        if ($date_from && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) {
            $date_from = '';
        }
        $date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';

        // Get sort parameters
        $orderby = isset($_GET['orderby']) ? sanitize_text_field($_GET['orderby']) : 'date';
        $order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'desc';

        // Get all activities with filters
        $activities_data = $this->get_filtered_activities($action_filter, $user_filter, $performed_by_filter, $date_from, $date_to);
        
        // Sort activities
        $sorted_data = $this->sort_activities($activities_data, $orderby, $order);
        
        $total_items = $sorted_data['total_items'];
        $total_pages = $sorted_data['total_pages'];
        $current_page = $sorted_data['current_page'];
        $activities = $sorted_data['items'];

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Account Lock Activity Log', 'account-locker'); ?></h1>

            <!-- Filters -->
            <div class="tablenav top">
                <form method="get" action="">
                    <input type="hidden" name="page" value="account-lock-activity" />
                    
                    <!-- Action Filter -->
                    <select name="filter_action">
                        <option value=""><?php esc_html_e('All Actions', 'account-locker'); ?></option>
                        <option value="locked" <?php selected($action_filter, 'locked'); ?>><?php esc_html_e('Locked', 'account-locker'); ?></option>
                        <option value="unlocked" <?php selected($action_filter, 'unlocked'); ?>><?php esc_html_e('Unlocked', 'account-locker'); ?></option>
                    </select>

                    <!-- User Filter -->
                    <select name="filter_user">
                        <option value="0"><?php esc_html_e('All Users', 'account-locker'); ?></option>
                        <?php
                        $users = get_users(array('fields' => array('ID', 'display_name')));
                        foreach ($users as $user) {
                            echo '<option value="' . esc_attr($user->ID) . '" ' . selected($user_filter, $user->ID, false) . '>' . 
                                 esc_html($user->display_name) . '</option>';
                        }
                        ?>
                    </select>

                    <!-- Performed By Filter -->
                    <select name="filter_performed_by">
                        <option value=""><?php esc_html_e('All Performers', 'account-locker'); ?></option>
                        <option value="system" <?php selected($performed_by_filter, 'system'); ?>><?php esc_html_e('System', 'account-locker'); ?></option>
                        <?php
                        foreach ($users as $user) {
                            echo '<option value="' . esc_attr($user->ID) . '" ' . selected($performed_by_filter, $user->ID, false) . '>' . 
                                 esc_html($user->display_name) . '</option>';
                        }
                        ?>
                    </select>

                    <!-- Date Range -->
                    <input type="date" name="date_from" value="<?php echo esc_attr($date_from); ?>" placeholder="<?php esc_attr_e('From', 'account-locker'); ?>" />
                    <input type="date" name="date_to" value="<?php echo esc_attr($date_to); ?>" placeholder="<?php esc_attr_e('To', 'account-locker'); ?>" />

                    <input type="submit" class="button" value="<?php esc_attr_e('Filter', 'account-locker'); ?>" />
                    <?php if ($action_filter || $user_filter || $performed_by_filter || $date_from || $date_to): ?>
                        <a href="<?php echo esc_url(admin_url('users.php?page=account-lock-activity')); ?>" class="button"><?php esc_html_e('Reset', 'account-locker'); ?></a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Activity Table -->
            <table class="widefat fixed striped">
                <thead>
                    <tr>
                        <?php
                        $columns = array(
                            'date' => __('Date', 'account-locker'),
                            'user' => __('User', 'account-locker'),
                            'action' => __('Action', 'account-locker'),
                            'performed_by' => __('Performed By', 'account-locker')
                        );

                        foreach ($columns as $column_key => $column_label) {
                            $current_order = ($orderby === $column_key) ? $order : 'asc';
                            $new_order = ($current_order === 'asc') ? 'desc' : 'asc';
                            $sort_url = add_query_arg(array(
                                'orderby' => $column_key,
                                'order' => $new_order
                            ));
                            
                            echo '<th class="sortable">';
                            echo '<a href="' . esc_url($sort_url) . '" class="sort-column">';
                            echo '<span>' . esc_html($column_label) . '</span>';
                            echo '<span class="sorting-indicator"></span>';
                            if ($orderby === $column_key) {
                                echo '<span class="sorted ' . esc_attr($order) . '"></span>';
                            }
                            echo '</a></th>';
                        }
                        ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($activities)): ?>
                        <tr>
                            <td colspan="4"><?php esc_html_e('No activity found.', 'account-locker'); ?></td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($activities as $activity): ?>
                            <tr>
                                <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($activity->timestamp))); ?></td>
                                <td><?php echo esc_html($activity->user_name); ?></td>
                                <td><?php echo esc_html($activity->action); ?></td>
                                <td><?php 
                                    if ($activity->performed_by == 0) {
                                        esc_html_e('System', 'account-locker');
                                    } else {
                                        echo esc_html($activity->performed_by_name ?? __('Unknown', 'account-locker'));
                                    }
                                ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="tablenav bottom">
                    <div class="tablenav-pages">
                        <span class="displaying-num">
                            <?php printf(
                                _n('%s item', '%s items', $total_items, 'account-locker'),
                                number_format_i18n($total_items)
                            ); ?>
                        </span>
                        <?php
                        echo paginate_links(array(
                            'base' => add_query_arg('paged', '%#%'),
                            'format' => '',
                            'prev_text' => __('&laquo;'),
                            'next_text' => __('&raquo;'),
                            'total' => $total_pages,
                            'current' => $current_page
                        ));
                        ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Get filtered activities
     */
    private function get_filtered_activities($action_filter, $user_filter, $performed_by_filter, $date_from, $date_to) {
        global $wpdb;
        
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = $this->per_page;
        $offset = ($paged - 1) * $per_page;
        
        $where_clauses = ['1=1'];
        $prepare_values = [];
        
        // Build where clauses
        if ($action_filter) {
            $where_clauses[] = 'action LIKE %s';
            $prepare_values[] = '%' . $wpdb->esc_like($action_filter) . '%';
        }
        
        if ($user_filter) {
            $where_clauses[] = 'a.user_id = %d';
            $prepare_values[] = $user_filter;
        }
        
        if ($performed_by_filter !== '') {
            if ($performed_by_filter === '0') {
                $where_clauses[] = 'a.performed_by = 0';
            } elseif ($performed_by_filter) {
                $where_clauses[] = 'a.performed_by = %d';
                $prepare_values[] = $performed_by_filter;
            }
        }
        
        if ($date_from) {
            $where_clauses[] = 'timestamp >= %s';
            $prepare_values[] = $date_from . ' 00:00:00';
        }
        
        if ($date_to) {
            $where_clauses[] = 'timestamp <= %s';
            $prepare_values[] = $date_to . ' 23:59:59';
        }
        
        $where_sql = implode(' AND ', $where_clauses);
        
        // Count total items
        $count_query = "SELECT COUNT(*) FROM {$this->table_name} a WHERE {$where_sql}";
        $total_items = !empty($prepare_values) 
            ? $wpdb->get_var($wpdb->prepare($count_query, $prepare_values))
            : $wpdb->get_var($count_query);
        
        // Get paginated results
        $query = "SELECT a.*, u.display_name as user_name, 
                 COALESCE(p.display_name, 'System') as performed_by_name
                 FROM {$this->table_name} a
                 LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
                 LEFT JOIN {$wpdb->users} p ON a.performed_by = p.ID
                 WHERE {$where_sql}
                 ORDER BY timestamp DESC
                 LIMIT %d OFFSET %d";
        
        // Add pagination parameters
        $prepare_values[] = $per_page;
        $prepare_values[] = $offset;
        
        $results = !empty($prepare_values)
            ? $wpdb->get_results($wpdb->prepare($query, $prepare_values))
            : $wpdb->get_results($query);
        
        return array(
            'items' => $results,
            'total_items' => $total_items,
            'total_pages' => ceil($total_items / $per_page),
            'current_page' => $paged
        );
    }

    /**
     * Sort activities
     */
    private function sort_activities(array $activities, string $orderby, string $order): array {
        if (empty($activities) || !isset($activities['items'])) {
            return $activities;
        }

        $items = $activities['items'];
        
        usort($items, function($a, $b) use ($orderby, $order) {
            $multiplier = strtolower($order) === 'desc' ? -1 : 1;
            
            switch ($orderby) {
                case 'date':
                    $a_time = strtotime($a->timestamp ?? '');
                    $b_time = strtotime($b->timestamp ?? '');
                    return $multiplier * ($a_time - $b_time);
                case 'user':
                    return $multiplier * strcasecmp($a->user_name ?? '', $b->user_name ?? '');
                case 'action':
                    return $multiplier * strcasecmp($a->action ?? '', $b->action ?? '');
                case 'performed_by':
                    $a_name = $a->performed_by == 0 ? 'System' : ($a->performed_by_name ?? 'Unknown');
                    $b_name = $b->performed_by == 0 ? 'System' : ($b->performed_by_name ?? 'Unknown');
                    return $multiplier * strcasecmp($a_name, $b_name);
                default:
                    return 0;
            }
        });

        $activities['items'] = $items;
        return $activities;
    }

    // Add pagination display
    private function display_pagination($total_pages, $current_page) {
        if ($total_pages <= 1) {
            return;
        }

        echo '<div class="tablenav-pages">';
        echo paginate_links(array(
            'base' => add_query_arg('paged', '%#%'),
            'format' => '',
            'prev_text' => __('&laquo;'),
            'next_text' => __('&raquo;'),
            'total' => $total_pages,
            'current' => $current_page
        ));
        echo '</div>';
    }
}