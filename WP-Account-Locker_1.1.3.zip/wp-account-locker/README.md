# WP_Account_Locker
Allows an admin to lock and unlock wordpress users accounts with a custom message.
